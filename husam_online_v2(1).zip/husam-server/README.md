# HUSAM Games — servidor online (modo de TESTE)

Truco, Xadrez, Damas, UNO, 21 e Sinuca 1x1 online com salas de espera, apostas de R$1 a R$100, carteira, pedidos de
depósito/saque aprovados pelo administrador e painel admin. **O saldo é de teste: nenhum
dinheiro real é movimentado.** Sem dependências (só Node 22.13+).

## Rodar no computador
    ADMIN_USERNAME=dono ADMIN_PASSWORD=uma-senha-forte-123 node server/index.js
    # jogadores: http://localhost:3000     admin: http://localhost:3000/admin
    node test/run-all.js     # testes

## Variáveis
- ADMIN_USERNAME / ADMIN_PASSWORD (mín. 8): cria o administrador na primeira subida
- PORT (3000), DATA_DIR (./data, onde fica husam.db — precisa ser disco persistente)
- TRUST_PROXY=1 se estiver atrás de proxy (Render, Railway, Nginx...)
- ALLOWED_ORIGIN: restringe a origem do WebSocket (ex. https://seusite.com)

## Hospedar
Qualquer host com Node 22+ e disco persistente (VPS, Fly.io, Railway, Render com disk). Use HTTPS.
Faça backup de `data/husam.db`.

## Regras de dinheiro (já implementadas)
Valores em centavos; toda mudança de saldo gera linha no extrato; a aposta é retida no início
da partida; o vencedor recebe o pote (menos taxa configurável, padrão 0%); empate ou queda do
servidor devolvem a aposta; saque retém o valor na hora e devolve se recusado.

## Antes de usar dinheiro real
Exige gateway de pagamento próprio, verificação de idade/identidade e análise jurídica
(apostas têm regulação no Brasil). Isto é a base técnica, não uma autorização.

## Jogos online
Truco (Mineiro/Paulista), Xadrez (regras completas), Damas brasileiras (captura obrigatória pela maioria),
UNO 1x1, 21 1x1 (melhor de 3 rodadas, 1ª carta virada), Sinuca 8 (física no servidor). Todas as regras
rodam no servidor: o celular só manda a jogada. Empate devolve as apostas.

## Celular
O site é responsivo e instalável: no iPhone abra no Safari > Compartilhar > Adicionar à Tela de Início;
no Android, Chrome > Instalar app. Precisa estar em https (qualquer host abaixo já dá).

## Colocar no ar (exemplo Render.com, dá pra fazer pelo celular)
1. Suba esta pasta num repositório do GitHub.
2. Render > New > Web Service > conecte o repositório. Runtime Node, Start Command: `node server/index.js`.
3. Environment: ADMIN_USERNAME, ADMIN_PASSWORD (forte), TRUST_PROXY=1, NODE_VERSION=22.
4. Adicione um Disk (persistente) montado em /data e defina DATA_DIR=/data. Sem disco o banco some a cada deploy.
5. Abra o endereço do serviço; o painel do dono fica em /admin.
