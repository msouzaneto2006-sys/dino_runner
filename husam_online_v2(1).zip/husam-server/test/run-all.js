const { spawnSync } = require('node:child_process');
let bad = 0;
for (const f of ['test/truco.test.js', 'test/boards.test.js', 'test/server.test.js']) {
  const r = spawnSync(process.execPath, ['--no-warnings', f], { stdio: 'inherit' });
  if (r.status !== 0) bad++;
}
process.exit(bad ? 1 : 0);
