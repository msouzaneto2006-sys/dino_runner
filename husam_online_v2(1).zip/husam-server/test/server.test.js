'use strict';
process.env.HUSAM_PAUSE_MS = '15';
const assert = require('assert');
const fs = require('fs'), os = require('os'), path = require('path');
const { createServer } = require('../server');
const T = require('../server/truco');

let passed = 0; const ok = n => { passed++; console.log('  ok -', n); };
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function start(opts = {}) {
  const srv = createServer({ quiet: true, adminUser: 'dono', adminPass: 'senhaforte1', memory: !opts.dataDir, ...opts });
  await new Promise(r => srv.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + srv.address().port;
  const call = async (method, p, body, token) => {
    const r = await fetch(base + p, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
    return { status: r.status, ...(await r.json()) };
  };
  return { srv, base, call, port: srv.address().port };
}

class Bot {
  constructor(port, token, name) {
    this.name = name; this.token = token; this.msgs = []; this.waiters = []; this.view = null; this.match = null; this.end = null; this.balance = null;
    this.ws = new WebSocket('ws://127.0.0.1:' + port + '/ws');
    this.ready = new Promise(res => { this.ws.onopen = () => { this.send({ t: 'auth', token }); res(); }; });
    this.ws.onmessage = e => { const m = JSON.parse(e.data); this.msgs.push(m); this.onMsg(m); this.waiters = this.waiters.filter(w => !w(m)); };
    this.ws.onerror = () => {};
  }
  onMsg(m) {
    if (m.t === 'hello') { this.balance = m.me.balance; this.hello = m; }
    if (m.t === 'balance') this.balance = m.balance;
    if (m.t === 'match') { this.match = m; this.end = null; }
    if (m.t === 'state') this.view = m.view;
    if (m.t === 'end') { this.end = m; this.balance = m.balance; }
  }
  send(o) { this.ws.send(JSON.stringify(o)); }
  wait(pred, ms = 5000) {
    const hit = this.msgs.find(pred); if (hit && pred.sticky) return Promise.resolve(hit);
    return new Promise((res, rej) => {
      const to = setTimeout(() => rej(new Error(this.name + ': timeout esperando ' + pred.toString().slice(0, 90))), ms);
      this.waiters.push(m => { if (pred(m)) { clearTimeout(to); res(m); return true; } return false; });
    });
  }
  close() { try { this.ws.close(); } catch (_) {} }
  // joga sozinho (aleatório) até o fim; retorna a mensagem 'end'
  autoplay(style = 'random') {
    const step = () => {
      const v = this.view && this.view.hand; if (!v || this.view.phase !== 'play' || this.end) return;
      if (v.pending && v.pending.from === 'opp') {
        const r = Math.random();
        this.send({ t: 'act', a: r < .6 ? 'accept' : r < .8 ? 'run' : (v.canReraise ? 'reraise' : 'accept') });
      } else if (!v.pending && v.turn === 'me') {
        if (v.canRaise && Math.random() < .2) this.send({ t: 'act', a: 'raise' });
        else this.send({ t: 'act', a: 'play', i: Math.floor(Math.random() * v.myCards.length) });
      }
    };
    const prev = this.ws.onmessage;
    this.ws.onmessage = e => { prev(e); const m = JSON.parse(e.data); if (m.t === 'state') setImmediate(step); };
    step();
    return this.wait(m => m.t === 'end', 60000);
  }
}

async function newUser(c, name, deposit) {
  const r = await c.call('POST', '/api/register', { username: name, password: 'segredo1' });
  assert(r.ok, 'registro ' + name + ': ' + r.error);
  if (deposit) {
    const d = await c.call('POST', '/api/deposit', { amount_cents: deposit }, r.token); assert(d.ok, d.error);
    const adm = (await c.call('POST', '/api/login', { username: 'dono', password: 'senhaforte1' })).token;
    assert(adm, 'login do admin');
    const a = await c.call('POST', `/api/admin/deposit/${d.id}/approve`, {}, adm); assert(a.ok, a.error);
  }
  return r;
}
const ledgerInvariant = (db) => {
  for (const u of db.prepare('SELECT id,balance_cents b FROM users').all()) {
    const s = db.prepare('SELECT COALESCE(SUM(amount_cents),0) s FROM ledger WHERE user_id=?').get(u.id).s;
    assert.strictEqual(s, u.b, 'ledger de ' + u.id + ' não bate com o saldo');
  }
};

(async () => {
  const { srv, call, port } = await start();
  const db = srv.db;
  const adm = (await call('POST', '/api/login', { username: 'dono', password: 'senhaforte1' })).token;

  // ---------- contas
  assert.strictEqual((await call('POST', '/api/register', { username: 'ab', password: 'segredo1' })).ok, false);
  assert.strictEqual((await call('POST', '/api/register', { username: 'bruno', password: '123' })).ok, false);
  const r1 = await call('POST', '/api/register', { username: 'Bruno', password: 'segredo1' }); assert(r1.ok);
  assert.strictEqual((await call('POST', '/api/register', { username: 'bRUNO', password: 'outrasenha' })).ok, false);
  assert.strictEqual((await call('POST', '/api/register', { username: 'dono', password: 'xxxxxxxx' })).ok, false);   // não dá para tomar o nome do admin
  assert.strictEqual((await call('POST', '/api/login', { username: 'bruno', password: 'segredo1' })).ok, true);
  for (let i = 0; i < 5; i++) await call('POST', '/api/login', { username: 'bruno', password: 'errada' + i });
  const locked = await call('POST', '/api/login', { username: 'bruno', password: 'segredo1' }); assert.strictEqual(locked.ok, false); assert(/Aguarde/.test(locked.error));
  assert.strictEqual((await call('GET', '/api/me')).status, 401);
  assert.strictEqual((await call('GET', '/api/admin/overview', null, r1.token)).status, 403);     // usuário comum não entra no admin
  ok('contas: cadastro, duplicado, senha curta, nome do admin protegido, bloqueio por tentativas, admin só para admin');
  const dbTxt = JSON.stringify(db.prepare('SELECT * FROM users').all());
  assert(!dbTxt.includes('segredo1')); ok('senha nunca guardada em texto puro');

  // ---------- carteira
  const ana = await newUser({ call }, 'ana', 0);
  assert.strictEqual((await call('POST', '/api/deposit', { amount_cents: 500 }, ana.token)).ok, false);       // abaixo do mínimo
  assert.strictEqual((await call('POST', '/api/deposit', { amount_cents: -1000 }, ana.token)).ok, false);
  assert.strictEqual((await call('POST', '/api/deposit', { amount_cents: 10.5 }, ana.token)).ok, false);
  const d = await call('POST', '/api/deposit', { amount_cents: 5000 }, ana.token); assert(d.ok);
  assert.strictEqual((await call('GET', '/api/me', null, ana.token)).user.balance, 0);                        // pedido não credita
  assert.strictEqual((await call('POST', `/api/admin/deposit/${d.id}/approve`, {}, ana.token)).status, 403);  // usuário não aprova o próprio depósito
  assert((await call('POST', `/api/admin/deposit/${d.id}/approve`, {}, adm)).ok);
  assert.strictEqual((await call('POST', `/api/admin/deposit/${d.id}/approve`, {}, adm)).ok, false);          // não aprova duas vezes
  assert.strictEqual((await call('GET', '/api/me', null, ana.token)).user.balance, 5000);
  const d2 = await call('POST', '/api/deposit', { amount_cents: 2000 }, ana.token); assert((await call('POST', `/api/admin/deposit/${d2.id}/reject`, {}, adm)).ok);
  assert.strictEqual((await call('GET', '/api/me', null, ana.token)).user.balance, 5000); ok('depósito: mínimo, aprovação única, rejeição não credita');
  assert.strictEqual((await call('POST', '/api/withdraw', { amount_cents: 1000, destination: 'ana@pix' }, ana.token)).ok, false);   // abaixo do mínimo de saque
  assert.strictEqual((await call('POST', '/api/withdraw', { amount_cents: 999900, destination: 'ana@pix' }, ana.token)).ok, false); // maior que o saldo
  const w = await call('POST', '/api/withdraw', { amount_cents: 3000, destination: 'ana@pix' }, ana.token); assert(w.ok);
  assert.strictEqual(w.balance, 2000);                                                                        // retido na hora
  assert((await call('POST', `/api/admin/withdraw/${w.id}/reject`, { note: 'teste' }, adm)).ok);
  assert.strictEqual((await call('GET', '/api/me', null, ana.token)).user.balance, 5000);                     // devolvido
  const w2 = await call('POST', '/api/withdraw', { amount_cents: 2500, destination: 'ana@pix' }, ana.token);
  assert((await call('POST', `/api/admin/withdraw/${w2.id}/approve`, {}, adm)).ok);
  assert.strictEqual((await call('GET', '/api/me', null, ana.token)).user.balance, 2500);
  assert.strictEqual((await call('POST', `/api/admin/withdraw/${w2.id}/reject`, {}, adm)).ok, false);         // já decidido: não devolve depois de pagar
  assert.strictEqual((await call('GET', '/api/me', null, ana.token)).user.balance, 2500);
  ledgerInvariant(db); ok('saque: mínimo, retém na hora, rejeitar devolve, aprovar mantém, não decide duas vezes');

  // ---------- partidas
  const bruno = await newUser({ call }, 'bruno2', 10000), carla = await newUser({ call }, 'carla', 10000);
  const sumBalances = () => db.prepare('SELECT SUM(balance_cents) s FROM users').get().s;
  const before = sumBalances();

  // 1) partida completa, sem taxa
  let B = new Bot(port, bruno.token, 'bruno'), C = new Bot(port, carla.token, 'carla'); await B.ready; await C.ready;
  await B.wait(m => m.t === 'hello'); await C.wait(m => m.t === 'hello');
  B.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 500 });
  await B.wait(m => m.t === 'queued');
  C.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 500 });
  await B.wait(m => m.t === 'match'); await C.wait(m => m.t === 'match');
  assert.strictEqual(B.match.pot, 1000); assert.notStrictEqual(B.match.you, C.match.you);
  await sleep(50);
  assert.strictEqual(db.prepare('SELECT balance_cents b FROM users WHERE username=?').get('bruno2').b, 9500);      // aposta retida
  const [eb, ec] = await Promise.all([B.autoplay(), C.autoplay()]);
  assert.notStrictEqual(eb.result, ec.result); const win = eb.result === 'win' ? 'bruno2' : 'carla';
  assert.strictEqual(sumBalances(), before);                                                                        // nada some, nada aparece
  assert.strictEqual(db.prepare('SELECT balance_cents b FROM users WHERE username=?').get(win).b, 10500);
  ledgerInvariant(db); ok('partida completa: aposta retida, vencedor recebe o pote, soma total intacta');
  B.close(); C.close(); await sleep(50);

  // 2) taxa da casa 10%
  assert((await call('POST', '/api/admin/settings', { rake_percent: 10 }, adm)).ok);
  B = new Bot(port, bruno.token, 'bruno'); C = new Bot(port, carla.token, 'carla'); await B.ready; await C.ready; await B.wait(m => m.t === 'hello'); await C.wait(m => m.t === 'hello');
  const tot0 = sumBalances();
  B.send({ t: 'queue', game: 'truco', mode: 'paulista', stake: 1000 }); await B.wait(m => m.t === 'queued'); C.send({ t: 'queue', game: 'truco', mode: 'paulista', stake: 1000 });
  await B.wait(m => m.t === 'match'); await C.wait(m => m.t === 'match');
  const [e1, e2] = await Promise.all([B.autoplay(), C.autoplay()]);
  const win2 = [e1, e2].find(e => e.result === 'win'); assert.strictEqual(win2.payout, 1800);
  const rakeSum = db.prepare("SELECT COALESCE(SUM(rake_cents),0) s FROM matches WHERE status='finished'").get().s;
  const approved = db.prepare("SELECT COALESCE(SUM(amount_cents),0) s FROM deposit_requests WHERE status='approved'").get().s;
  const paidOut = db.prepare("SELECT COALESCE(SUM(amount_cents),0) s FROM withdraw_requests WHERE status='approved'").get().s;
  assert.strictEqual(sumBalances() + rakeSum + paidOut, approved);          // todo centavo depositado está numa conta, na casa ou foi sacado
  assert.strictEqual(tot0 - sumBalances(), 200); ok('taxa da casa 10%: vencedor recebe 1800 de 2000, a casa fica com 200');
  B.close(); C.close(); await sleep(50);
  await call('POST', '/api/admin/settings', { rake_percent: 0 }, adm);

  // 3) fila: cancelar, saldo insuficiente, duas filas, apostas diferentes não casam
  B = new Bot(port, bruno.token, 'bruno'); C = new Bot(port, carla.token, 'carla'); await B.ready; await C.ready; await B.wait(m => m.t === 'hello'); await C.wait(m => m.t === 'hello');
  B.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 500 }); await B.wait(m => m.t === 'queued');
  B.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 500 }); await B.wait(m => m.t === 'err');
  C.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 2000 }); await C.wait(m => m.t === 'queued');         // outra aposta: não casa
  await sleep(100); assert(!B.match || B.end || true); assert(srv.hub.matches.size === 0);
  B.send({ t: 'cancel' }); await B.wait(m => m.t === 'unqueued'); C.send({ t: 'cancel' }); await C.wait(m => m.t === 'unqueued');
  assert.strictEqual(srv.hub.userQueue.size, 0);
  const pobre = await newUser({ call }, 'pobre', 0), P = new Bot(port, pobre.token, 'pobre'); await P.ready; await P.wait(m => m.t === 'hello');
  P.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 100 }); const er = await P.wait(m => m.t === 'err'); assert(/Saldo/.test(er.msg));
  P.send({ t: 'queue', game: 'poker', mode: 'x', stake: 100 }); await P.wait(m => m.t === 'err' && /dispon/.test(m.msg));
  P.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 123 }); await P.wait(m => m.t === 'err' && /inválido/.test(m.msg)); P.close();
  ok('fila: não entra 2x, apostas diferentes não casam, cancelar, saldo insuficiente, jogo/valor inválidos');

  // 4) desistir (sair no meio) paga o outro
  B.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 500 }); await B.wait(m => m.t === 'queued'); C.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 500 });
  await B.wait(m => m.t === 'match'); await C.wait(m => m.t === 'match'); await sleep(50);
  const tot1 = sumBalances(); B.send({ t: 'forfeit' });
  const [fe, fb] = await Promise.all([C.wait(m => m.t === 'end'), B.wait(m => m.t === 'end')]); assert.strictEqual(fe.result, 'win'); assert.strictEqual(fe.reason, 'forfeit'); assert.strictEqual(fe.payout, 1000);
  assert.strictEqual(fb.result, 'lose'); assert.strictEqual(sumBalances(), tot1 + 1000);   // aposta dos dois (1000) volta como pote
  ledgerInvariant(db); ok('desistência: quem sai perde a aposta, o outro recebe o pote');

  // 5) ações fora do lugar não mudam nada / não pagam duas vezes
  B.send({ t: 'act', a: 'play', i: 0 }); await B.wait(m => m.t === 'err');
  B.send({ t: 'forfeit' }); await sleep(50); ledgerInvariant(db);
  B.close(); C.close(); await sleep(50);

  // 6) queda de conexão e volta no meio da partida: continua de onde parou
  B = new Bot(port, bruno.token, 'bruno'); C = new Bot(port, carla.token, 'carla'); await B.ready; await C.ready; await B.wait(m => m.t === 'hello'); await C.wait(m => m.t === 'hello');
  B.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 200 }); await B.wait(m => m.t === 'queued'); C.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 200 });
  await B.wait(m => m.t === 'match'); await C.wait(m => m.t === 'match'); for (let i = 0; i < 100 && !B.view; i++) await sleep(10);
  const cardsBefore = JSON.stringify(B.view.hand.myCards); B.close(); await sleep(100);
  const B2 = new Bot(port, bruno.token, 'bruno-volta'); await B2.ready;
  for (let i = 0; i < 100 && !(B2.match && B2.view); i++) await sleep(10); const mm = B2.match; assert(B2.view, 'sem estado após reconectar');
  assert.strictEqual(JSON.stringify(B2.view.hand.myCards), cardsBefore); assert.strictEqual(mm.stake, 200);
  // mesma conta em dois lugares: o segundo derruba o primeiro
  const B3 = new Bot(port, bruno.token, 'bruno-3'); await B3.ready; await B2.wait(m => m.t === 'replaced'); await B3.wait(m => m.t === 'hello');
  ok('reconexão: volta para a mesma partida com as mesmas cartas; 2º login derruba o 1º');
  const [f1, f2] = await Promise.all([B3.autoplay(), C.autoplay()]); assert.notStrictEqual(f1.result, f2.result);
  B3.close(); C.close(); B2.close(); await sleep(50); ledgerInvariant(db);

  // 7) tempo esgotado: quem não joga perde
  db.prepare("UPDATE settings SET value='1' WHERE key='turn_seconds'").run();
  B = new Bot(port, bruno.token, 'bruno'); C = new Bot(port, carla.token, 'carla'); await B.ready; await C.ready; await B.wait(m => m.t === 'hello'); await C.wait(m => m.t === 'hello');
  B.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 100 }); await B.wait(m => m.t === 'queued'); C.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 100 });
  await B.wait(m => m.t === 'match'); await C.wait(m => m.t === 'match');
  const [te] = await Promise.all([B.wait(m => m.t === 'end', 4000), C.wait(m => m.t === 'end', 4000)]); assert.strictEqual(te.reason, 'timeout');
  const loserSide = te.result === 'lose' ? B.match.you : C.match.you; assert(loserSide);
  ok('tempo esgotado: perde a partida e o outro recebe o pote'); B.close(); C.close(); await sleep(50);
  db.prepare("UPDATE settings SET value='60' WHERE key='turn_seconds'").run();
  ledgerInvariant(db);

  // 8) admin: ajuste manual exige motivo; configurações com limites
  assert.strictEqual((await call('POST', '/api/admin/adjust', { user_id: 2, amount_cents: 500, note: '' }, adm)).ok, false);
  const aj = await call('POST', '/api/admin/adjust', { user_id: ana.user.id, amount_cents: 700, note: 'crédito de teste' }, adm); assert(aj.ok);
  assert.strictEqual((await call('POST', '/api/admin/adjust', { user_id: ana.user.id, amount_cents: -99999999, note: 'tirar tudo' }, adm)).ok, false);   // não deixa negativo
  assert.strictEqual((await call('POST', '/api/admin/settings', { rake_percent: 99 }, adm)).ok, false);
  assert.strictEqual((await call('POST', '/api/admin/settings', { stakes: [100, 200, 500, 1000] }, adm)).ok, true);
  assert.strictEqual((await call('POST', '/api/admin/settings', { stakes: [5] }, adm)).ok, false);
  await call('POST', '/api/admin/settings', { stakes: [100, 200, 500, 1000, 2000, 2500, 5000, 10000] }, adm);
  ledgerInvariant(db); ok('admin: ajuste com motivo, saldo nunca negativo, configurações com limites');

  // 9) mensagens maliciosas/lixo não derrubam o servidor
  const raw = new WebSocket('ws://127.0.0.1:' + port + '/ws'); await new Promise(r => raw.onopen = r);
  for (const junk of ['nao-json', '{"t":"act"}', '{"t":"auth","token":"x"}', '[]', 'null', '{"t":"queue"}']) raw.send(junk);
  await sleep(100); assert.strictEqual((await call('GET', '/api/health')).ok, true); raw.close();
  ok('lixo no WebSocket não derruba o servidor');

  const finalInv = srv.db.prepare("SELECT COUNT(*) c FROM matches WHERE status='active'").get().c; assert.strictEqual(finalInv, 0);
  srv.shutdown();

  // ---------- queda do servidor no meio da partida: apostas devolvidas ao reiniciar
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'husam-'));
  let s2 = await start({ dataDir: dir });
  const u1 = await newUser(s2, 'rui', 5000), u2 = await newUser(s2, 'sara', 5000);
  const X = new Bot(s2.port, u1.token, 'rui'), Y = new Bot(s2.port, u2.token, 'sara'); await X.ready; await Y.ready; await X.wait(m => m.t === 'hello'); await Y.wait(m => m.t === 'hello');
  X.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 2000 }); await X.wait(m => m.t === 'queued'); Y.send({ t: 'queue', game: 'truco', mode: 'mineiro', stake: 2000 });
  await X.wait(m => m.t === 'match'); await sleep(50);
  assert.strictEqual(s2.srv.db.prepare("SELECT balance_cents b FROM users WHERE username='rui'").get().b, 3000);
  X.close(); Y.close(); s2.srv.hub.close(); s2.srv.close(); s2.srv.db.close();       // "queda": não finaliza a partida
  const s3 = await start({ dataDir: dir });
  const bal = n => s3.srv.db.prepare('SELECT balance_cents b FROM users WHERE username=?').get(n).b;
  assert.strictEqual(bal('rui'), 5000); assert.strictEqual(bal('sara'), 5000);
  assert.strictEqual(s3.srv.db.prepare("SELECT status FROM matches").get().status, 'aborted'); ledgerInvariant(s3.srv.db);
  ok('queda do servidor: ao reiniciar, a aposta dos dois volta e a partida fica "abortada"');
  s3.srv.shutdown();
  // sessão continua valendo depois de reiniciar
  const s4 = await start({ dataDir: dir }); assert((await s4.call('GET', '/api/me', null, u1.token)).ok); ok('login continua valendo depois de reiniciar'); s4.srv.shutdown();

  console.log(`servidor: ${passed} grupos de testes OK`);
  process.exit(0);
})().catch(e => { console.error('FALHOU:', e && e.stack || e); process.exit(1); });
