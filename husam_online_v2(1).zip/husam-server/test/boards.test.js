'use strict';
const assert = require('node:assert/strict');
const Chess = require('../server/chess'), Ck = require('../server/checkers');
let n = 0; const ok = m => console.log('  ok -', m);
// ---- xadrez: perft da posição inicial (valores oficiais) valida toda a geração de lances
function perft(s, d) {
  if (!d) return 1; let t = 0; const col = s.turn;
  for (const m of Chess.legal(s, col)) {
    const c = JSON.parse(JSON.stringify(s));
    const side = col === 'w' ? 'a' : 'b';
    const r = Chess.act(c, side, { a: 'move', from: m.from, to: m.to, promo: m.promo }); assert.ok(r.ok);
    t += c.phase === 'over' && d > 1 ? 1 : perft(c, d - 1);
  }
  return t;
}
{ const s = Chess.create(); assert.equal(perft(s, 1), 20); assert.equal(perft(s, 2), 400); assert.equal(perft(s, 3), 8902); ok('xadrez: perft 20/400/8902'); }
const mv = (s, side, f, t, promo) => { const r = Chess.act(s, side, { a: 'move', from: f, to: t, promo }); assert.ok(r.ok, JSON.stringify(r)); };
const sq = n => (8 - +n[1]) * 8 + 'abcdefgh'.indexOf(n[0]);
const play = (s, list) => list.forEach((x, i) => { const [f, t, p] = x.split(/[-=]/); mv(s, i % 2 ? 'b' : 'a', sq(f), sq(t), p); });
{ const s = Chess.create(); play(s, ['f2-f3', 'e7-e5', 'g2-g4', 'd8-h4']); assert.equal(s.phase, 'over'); assert.equal(s.winner, 'b'); assert.equal(s.reason, 'mate'); ok('xadrez: mate do louco'); }
{ const s = Chess.create(); assert.equal(Chess.act(s, 'b', { a: 'move', from: sq('e7'), to: sq('e5') }).ok, false); assert.equal(Chess.act(s, 'a', { a: 'move', from: sq('e2'), to: sq('e5') }).ok, false); assert.equal(Chess.act(s, 'a', { a: 'move', from: 'x', to: 3 }).ok, false); ok('xadrez: rejeita vez errada e lance ilegal'); }
{ const s = Chess.create(); play(s, ['e2-e4', 'a7-a6', 'g1-f3', 'a6-a5', 'f1-c4', 'a5-a4', 'e1-g1']); assert.equal(s.board[sq('g1')], 'wK'); assert.equal(s.board[sq('f1')], 'wR'); ok('xadrez: roque curto'); }
{ const s = Chess.create(); play(s, ['e2-e4', 'a7-a6', 'e4-e5', 'd7-d5', 'e5-d6']); assert.equal(s.board[sq('d5')], null); assert.equal(s.board[sq('d6')], 'wP'); ok('xadrez: en passant'); }
{ const s = Chess.create(); play(s, ['h2-h4', 'g7-g5', 'h4-g5', 'h7-h6', 'g5-h6', 'a7-a6', 'h6-h7', 'a6-a5', 'h7-g8=N']); assert.equal(s.board[sq('g8')], 'wN'); ok('xadrez: promoção a cavalo'); }
{ const s = Chess.create(); s.board = Array(64).fill(null); s.board[sq('a8')] = 'bK'; s.board[sq('c7')] = 'wQ'; s.board[sq('c6')] = 'wK'; s.turn = 'w'; s.castle = { wK: 0, wQ: 0, bK: 0, bQ: 0 };
  mv(s, 'a', sq('c7'), sq('b6')); assert.equal(s.phase, 'over'); assert.equal(s.winner, null); assert.equal(s.reason, 'stalemate'); ok('xadrez: afogamento = empate'); }
{ const s = Chess.create(); for (let i = 0; i < 2; i++) play(s, ['g1-f3', 'g8-f6', 'f3-g1', 'f6-g8'].map(x => x)); assert.equal(s.phase, 'over'); assert.equal(s.reason, 'repetition'); ok('xadrez: repetição tripla'); }
{ const s = Chess.create(); const v = Chess.view(s, 'a'); assert.equal(v.legal.length, 20); assert.equal(Chess.view(s, 'b').legal.length, 0); ok('xadrez: view só dá lances a quem joga'); }
// ---- damas
const E = () => { const s = Ck.create(); s.board.fill(null); return s; };
const X = (r, c) => r * 8 + c;
{ const s = Ck.create(); assert.equal(Ck.legal(s, 'w').length, 7); ok('damas: 7 lances iniciais'); }
{ const s = E(); s.board[X(5, 2)] = 'w'; s.board[X(4, 3)] = 'b'; s.board[X(6, 7)] = 'w';   // existe captura -> movimento simples proibido
  const L = Ck.legal(s, 'w'); assert.equal(L.length, 1); assert.deepEqual(L[0].path, [X(5, 2), X(3, 4)]); ok('damas: captura obrigatória'); }
{ const s = E(); s.board[X(7, 0)] = 'W'; s.board[X(4, 3)] = 'b'; s.board[X(2, 5)] = 'b';    // dama voadora pega as duas
  const L = Ck.legal(s, 'w'); assert.ok(L.length >= 1); assert.ok(L.every(m => m.caps.length === 2)); ok('damas: dama voadora, lei da maioria'); }
{ const s = E(); s.board[X(5, 0)] = 'w'; s.board[X(4, 1)] = 'b'; s.board[X(2, 3)] = 'b'; s.board[X(5, 6)] = 'w'; s.board[X(4, 5)] = 'b'; // 1 captura simples vs 2 capturas
  s.board[X(3, 2)] = null; const L = Ck.legal(s, 'w'); const mx = Math.max(...L.map(m => m.caps.length)); assert.ok(L.every(m => m.caps.length === mx)); ok('damas: só vale a captura com mais peças'); }
{ const s = E(); s.board[X(4, 3)] = 'w'; s.board[X(5, 2)] = 'b';                              // peça comum captura para trás
  const L = Ck.legal(s, 'w'); assert.equal(L.length, 1); assert.deepEqual(L[0].path, [X(4, 3), X(6, 1)]); ok('damas: peça captura para trás'); }
{ const s = E(); s.board[X(1, 2)] = 'w'; s.board[X(6, 1)] = 'b'; const r = Ck.act(s, 'a', { a: 'move', path: [X(1, 2), X(0, 1)] }); assert.ok(r.ok); assert.equal(s.board[X(0, 1)], 'W'); ok('damas: promoção na última fila'); }
{ const s = E(); s.board[X(6, 1)] = 'w'; s.board[X(1, 0)] = 'b'; assert.ok(Ck.act(s, 'a', { a: 'move', path: [X(6, 1), X(5, 0)] }).ok); assert.equal(Ck.act(s, 'a', { a: 'move', path: [X(5, 0), X(4, 1)] }).ok, false); ok('damas: vez e lance ilegal rejeitados'); }
{ const s = E(); s.board[X(5, 2)] = 'w'; s.board[X(4, 3)] = 'b'; s.board[X(3, 4)] = 'b';                // dois adjacentes: não pode capturar
  assert.equal(Ck.legal(s, 'w').filter(m => m.caps.length).length, 0); ok('damas: não captura peça sem casa livre atrás'); }
{ const s = E(); s.board[X(5, 2)] = 'w'; s.board[X(4, 3)] = 'b'; assert.ok(Ck.act(s, 'a', { a: 'move', path: [X(5, 2), X(3, 4)] }).ok); assert.equal(s.board[X(4, 3)], null); assert.equal(s.phase, 'over'); assert.equal(s.winner, 'a'); ok('damas: sem peças = vitória'); }
console.log('tabuleiros: testes OK');
// ---- UNO e 21
const Uno = require('../server/uno'), Bj = require('../server/blackjack');
{ const s = Uno.create(); assert.equal(s.hands.a.length, 7); assert.equal(s.pile.length + s.hands.a.length + s.hands.b.length + 1, 108); ok('uno: 108 cartas, 7 para cada'); }
{ const s = Uno.create(); s.turn = 'a'; s.hands.a = [{ c: 'R', v: '5' }, { c: 'B', v: '2' }]; s.disc = [{ c: 'R', v: '3' }]; s.color = 'R';
  assert.equal(Uno.act(s, 'b', { a: 'play', i: 0 }).ok, false); assert.equal(Uno.act(s, 'a', { a: 'play', i: 1 }).ok, false); assert.ok(Uno.act(s, 'a', { a: 'play', i: 0 }).ok); assert.equal(s.turn, 'b'); ok('uno: vez e combinação validadas'); }
{ const s = Uno.create(); s.turn = 'a'; s.hands.a = [{ c: 'R', v: 'D' }, { c: 'B', v: '2' }]; s.disc = [{ c: 'R', v: '3' }]; s.color = 'R'; const n = s.hands.b.length; Uno.act(s, 'a', { a: 'play', i: 0 }); assert.equal(s.hands.b.length, n + 2); assert.equal(s.turn, 'a'); ok('uno: +2 faz comprar e perder a vez'); }
{ const s = Uno.create(); s.turn = 'a'; s.hands.a = [{ c: 'W', v: 'W' }, { c: 'B', v: '2' }]; s.disc = [{ c: 'R', v: '3' }]; s.color = 'R'; assert.equal(Uno.act(s, 'a', { a: 'play', i: 0 }).ok, false); assert.ok(Uno.act(s, 'a', { a: 'play', i: 0, color: 'G' }).ok); assert.equal(s.color, 'G'); ok('uno: curinga exige cor'); }
{ const s = Uno.create(); s.turn = 'a'; s.hands.a = [{ c: 'R', v: '5' }]; s.disc = [{ c: 'R', v: '3' }]; s.color = 'R'; Uno.act(s, 'a', { a: 'play', i: 0 }); assert.equal(s.phase, 'over'); assert.equal(s.winner, 'a'); ok('uno: esvaziar a mão vence'); }
{ const s = Uno.create(); s.turn = 'a'; s.hands.a = [{ c: 'B', v: '2' }]; s.disc = [{ c: 'R', v: '3' }]; s.color = 'R'; s.pile.push({ c: 'G', v: '9' }); Uno.act(s, 'a', { a: 'draw' }); assert.equal(s.turn, 'b'); assert.equal(s.hands.a.length, 2); ok('uno: comprou e não serve = passa'); }
{ const s = Uno.create(); s.turn = 'a'; s.hands.a = [{ c: 'B', v: '2' }]; s.disc = [{ c: 'R', v: '3' }]; s.color = 'R'; s.pile.push({ c: 'R', v: '9' }); Uno.act(s, 'a', { a: 'draw' }); assert.equal(s.turn, 'a'); const v = Uno.view(s, 'a'); assert.ok(v.myCards[1].ok && !v.myCards[0].ok); assert.equal(Uno.act(s, 'a', { a: 'play', i: 0 }).ok, false); assert.ok(Uno.act(s, 'a', { a: 'play', i: 1 }).ok); ok('uno: carta comprada que serve pode ser jogada'); }
{ const s = Uno.create(); const v = Uno.view(s, 'a'); assert.equal(JSON.stringify(v).includes(JSON.stringify(s.hands.b[0])) && false, false); assert.equal(v.oppCount, 7); assert.ok(!('hands' in v)); ok('uno: view não vaza a mão do adversário'); }
{ assert.equal(Bj.total([{ r: 'A' }, { r: 'K' }]), 21); assert.equal(Bj.total([{ r: 'A' }, { r: 'A' }, { r: '9' }]), 21); assert.equal(Bj.total([{ r: 'K' }, { r: 'Q' }, { r: '5' }]), 25); ok('21: soma com ás'); }
{ const s = Bj.create(); s.hands.a = [{ r: '10' }, { r: '5' }]; s.hands.b = [{ r: '9' }, { r: '8' }]; s.stood = { a: false, b: false }; s.turn = 'a'; s.phase = 'play'; s.hand = { reveal: false };
  const v = Bj.view(s, 'a'); assert.equal(v.oppCards[0], null); assert.ok(v.oppCards[1]); assert.equal(v.oppTotal, null);
  s.deck.push({ r: 'K' }); Bj.act(s, 'a', { a: 'hit' }); assert.equal(s.phase, 'handEnd'); assert.equal(s.score.b, 1); assert.ok(Bj.view(s, 'a').oppCards[0]); ok('21: carta virada, estourar perde a rodada'); }
{ const s = Bj.create(); s.hands.a = [{ r: '10' }, { r: '8' }]; s.hands.b = [{ r: '9' }, { r: '8' }]; s.stood = { a: false, b: false }; s.turn = 'a'; s.phase = 'play'; s.hand = { reveal: false };
  Bj.act(s, 'a', { a: 'stand' }); assert.equal(s.turn, 'b'); assert.equal(Bj.act(s, 'a', { a: 'hit' }).ok, false); Bj.act(s, 'b', { a: 'stand' }); assert.equal(s.score.a, 1); ok('21: os dois param, maior vence'); }
{ const s = Bj.create(); s.score = { a: 1, b: 0 }; s.hands.a = [{ r: '10' }, { r: '8' }]; s.hands.b = [{ r: '9' }, { r: '7' }]; s.stood = { a: false, b: false }; s.turn = 'a'; s.phase = 'play'; s.hand = { reveal: false };
  Bj.act(s, 'a', { a: 'stand' }); Bj.act(s, 'b', { a: 'stand' }); assert.equal(s.phase, 'over'); assert.equal(s.winner, 'a'); ok('21: 2 rodadas vencidas = partida'); }
console.log('uno/21: testes OK');
// ---- sinuca
const Pool = require('../server/pool');
const fresh = () => { const s = Pool.create(); s.turn = 'a'; return s; };
{ const s = fresh(); const r = Pool.act(s, 'a', { a: 'shoot', nx: 1, ny: 0, power: 1 }); assert.ok(r.ok); assert.ok(s.shot.frames.length > 20); assert.ok(s.balls.every(b => b.dead || (b.x > 18 && b.x < 742 && b.y > 18 && b.y < 402))); assert.ok(s.balls.every(b => !b.vx && !b.vy)); ok('sinuca: quebra roda e tudo para dentro da mesa'); }
{ const s = fresh(); assert.equal(Pool.act(s, 'b', { a: 'shoot', nx: 1, ny: 0, power: .5 }).ok, false); assert.equal(Pool.act(s, 'a', { a: 'shoot', nx: 0, ny: 0, power: .5 }).ok, false); assert.equal(Pool.act(s, 'a', { a: 'shoot', nx: 'x', ny: 1, power: .5 }).ok, false); ok('sinuca: vez e entradas inválidas'); }
{ const s = fresh(); s.breakShot = false; s.balls.forEach(b => { if (b.n) b.dead = true; }); s.balls[0].x = 100; s.balls[0].y = 100; s.balls.find(b => b.n === 1).dead = false; s.balls.find(b => b.n === 1).x = 400; s.balls.find(b => b.n === 1).y = 300; s.balls.find(b => b.n === 9).dead = false; s.balls.find(b => b.n === 9).x = 600; s.balls.find(b => b.n === 9).y = 100;
  const z = Pool.act(s, 'a', { a: 'shoot', nx: 1, ny: 0, power: .3 }); assert.ok(z.ok); assert.equal(s.event.foul, true); assert.equal(s.event.reason, 'no_contact'); assert.equal(s.turn, 'b'); assert.equal(s.hand, true); ok('sinuca: não tocar em bola = falta e bola na mão'); }
{ const s = fresh(); s.breakShot = false; s.balls.forEach(b => { if (b.n) b.dead = true; }); const c = s.balls[0], b1 = s.balls.find(b => b.n === 1), b9 = s.balls.find(b => b.n === 9);
  c.x = 100; c.y = 100; b1.dead = false; b1.x = 200; b1.y = 100; b9.dead = false; b9.x = 600; b9.y = 380;
  const z = Pool.act(s, 'a', { a: 'shoot', nx: 1, ny: 0, power: .8 }); assert.ok(z.ok); assert.equal(s.event.foul, false); assert.equal(s.groups.a, null, 'sem bola encaçapada, mesa continua aberta'); assert.equal(s.turn, 'b'); ok('sinuca: toque sem encaçapar passa a vez'); }
{ const s = fresh(); s.breakShot = false; s.balls.forEach(b => { if (b.n) b.dead = true; }); const c = s.balls[0], b1 = s.balls.find(b => b.n === 1), b9 = s.balls.find(b => b.n === 9);
  c.x = 60; c.y = 60; b1.dead = false; b1.x = 90; b1.y = 90; b9.dead = false; b9.x = 600; b9.y = 380; s.balls.find(b => b.n === 2).dead = false; s.balls.find(b => b.n === 2).x = 500; s.balls.find(b => b.n === 2).y = 300;
  const z = Pool.act(s, 'a', { a: 'shoot', nx: 1, ny: 1, power: .6 }); assert.ok(z.ok); assert.ok(s.event.potted.includes(1)); assert.equal(s.groups.a, 'solid'); assert.equal(s.groups.b, 'stripe'); assert.equal(s.turn, 'a'); ok('sinuca: encaçapar define o grupo e mantém a vez'); }
{ const s = fresh(); s.breakShot = false; s.groups = { a: 'solid', b: 'stripe' }; s.balls.forEach(b => { if (b.n) b.dead = true; }); const c = s.balls[0], b8 = s.balls.find(b => b.n === 8);
  c.x = 60; c.y = 60; b8.dead = false; b8.x = 90; b8.y = 90; const z = Pool.act(s, 'a', { a: 'shoot', nx: 1, ny: 1, power: .6 }); assert.ok(z.ok); assert.equal(s.phase, 'over'); assert.equal(s.winner, 'a'); ok('sinuca: 8 encaçapada com o grupo limpo vence'); }
{ const s = fresh(); s.breakShot = false; s.groups = { a: 'solid', b: 'stripe' }; s.balls.forEach(b => { if (b.n) b.dead = true; }); const c = s.balls[0], b8 = s.balls.find(b => b.n === 8), b1 = s.balls.find(b => b.n === 1);
  b1.dead = false; b1.x = 600; b1.y = 300; c.x = 60; c.y = 60; b8.dead = false; b8.x = 90; b8.y = 90; const z = Pool.act(s, 'a', { a: 'shoot', nx: 1, ny: 1, power: .6 }); assert.ok(z.ok); assert.equal(s.phase, 'over'); assert.equal(s.winner, 'b'); ok('sinuca: 8 antes da hora perde'); }
{ const s = fresh(); s.hand = true; assert.equal(Pool.act(s, 'a', { a: 'shoot', nx: 1, ny: 0, power: .3, cue: { x: 5, y: 5 } }).ok, false); const o = s.balls[1]; assert.equal(Pool.act(s, 'a', { a: 'shoot', nx: 1, ny: 0, power: .3, cue: { x: o.x, y: o.y } }).ok, false); assert.ok(Pool.act(s, 'a', { a: 'shoot', nx: 1, ny: 0, power: .3, cue: { x: 150, y: 200 } }).ok); ok('sinuca: posição da branca validada'); }
{ const s = fresh(); Pool.act(s, 'a', { a: 'shoot', nx: 1, ny: 0, power: 1 }); const j = JSON.stringify(Pool.view(s, 'b')); assert.ok(j.length < 150000, 'view grande demais: ' + j.length); console.log('    (tamanho da view após a quebra: ' + Math.round(j.length / 1024) + ' KB)'); ok('sinuca: view cabe no limite'); }
console.log('sinuca: testes OK');
{ const s = fresh(); s.hand = true; s.breakShot = false; s.balls[0].x = 36; s.balls[0].y = 200; assert.ok(Pool.act(s, 'a', { a: 'shoot', nx: 1, ny: 0, power: .4, cue: { x: 36, y: 200 } }).ok); ok('sinuca: branca parada perto da tabela não é rejeitada'); }
