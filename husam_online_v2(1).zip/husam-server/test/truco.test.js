'use strict';
const assert = require('assert');
const T = require('../server/truco');
let n = 0; const ok = (name) => { n++; console.log('  ok -', name); };

// --- regras de vaza
assert.strictEqual(T.decideHand(['a','a'],'b'),'a'); assert.strictEqual(T.decideHand(['t'],'a'),null);
assert.strictEqual(T.decideHand(['t','b'],'a'),'b'); assert.strictEqual(T.decideHand(['a','t'],'b'),'a');
assert.strictEqual(T.decideHand(['a','b'],'a'),null); assert.strictEqual(T.decideHand(['a','b','t'],'b'),'a');
assert.strictEqual(T.decideHand(['t','t','b'],'a'),'b'); assert.strictEqual(T.decideHand(['t','t','t'],'b'),'b');
ok('decideHand (empates e desempates)');

// --- força das cartas
const st = (m,v,r,s)=>T.strength(m,v,{r,s});
assert(st('mineiro',null,'4','♣')>st('mineiro',null,'7','♥')); assert(st('mineiro',null,'7','♥')>st('mineiro',null,'A','♠'));
assert(st('mineiro',null,'A','♠')>st('mineiro',null,'7','♦')); assert(st('mineiro',null,'7','♦')>st('mineiro',null,'3','♠'));
assert.strictEqual(T.manilhaRank({r:'3',s:'♠'}),'4'); assert.strictEqual(T.manilhaRank({r:'7',s:'♠'}),'Q');
const vi={r:'7',s:'♠'}; assert(st('paulista',vi,'Q','♣')>st('paulista',vi,'Q','♥')); assert(st('paulista',vi,'Q','♦')>st('paulista',vi,'3','♠'));
ok('forças: manilhas fixas (mineiro) e vira (paulista)');

assert.deepStrictEqual([T.raiseAfter('mineiro',2),T.raiseAfter('mineiro',4),T.raiseAfter('mineiro',6),T.raiseAfter('mineiro',10),T.raiseAfter('mineiro',12)],[4,6,10,12,null]);
assert.deepStrictEqual([T.raiseAfter('paulista',1),T.raiseAfter('paulista',3),T.raiseAfter('paulista',6),T.raiseAfter('paulista',9),T.raiseAfter('paulista',12)],[3,6,9,12,null]);
ok('escada de aumentos');

// --- visão não vaza a mão do adversário
{
  const s=T.create('mineiro'); const v=T.view(s,'a'); const txt=JSON.stringify(v);
  for(const c of s.hand.hands.b) assert(!txt.includes(JSON.stringify(c)) || s.hand.hands.a.some(x=>x.r===c.r&&x.s===c.s));
  assert.strictEqual(v.hand.myCards.length,3); assert.strictEqual(v.hand.oppCount,3);
  ok('a visão só mostra as minhas cartas');
}

// --- ações inválidas
{
  const s=T.create('mineiro'); const first=s.hand.turn, second=first==='a'?'b':'a';
  assert(!T.act(s,second,{a:'play',i:0}).ok);              // fora da vez
  assert(!T.act(s,first,{a:'play',i:9}).ok);               // carta inexistente
  assert(!T.act(s,first,{a:'accept'}).ok);                 // nada a aceitar
  assert(!T.act(s,second,{a:'raise'}).ok);                 // pedir fora da vez
  assert(T.act(s,first,{a:'raise'}).ok);                   // vez de quem abre
  assert(!T.act(s,first,{a:'play',i:0}).ok);               // com pedido pendente não joga
  assert(!T.act(s,first,{a:'accept'}).ok);                 // quem pediu não responde
  assert(T.act(s,second,{a:'accept'}).ok); assert.strictEqual(s.hand.points,4);
  assert(!T.act(s,first,{a:'raise'}).ok);                  // quem pediu por último não pede de novo seguido
  ok('validações de vez, carta e pedidos');
}
// --- correr entrega o valor anterior a quem pediu
{
  const s=T.create('mineiro'); const f=s.hand.turn, o=f==='a'?'b':'a';
  T.act(s,f,{a:'raise'}); T.act(s,o,{a:'run'});
  assert.strictEqual(s.score[f],2); assert.strictEqual(s.phase,'handEnd'); ok('correr: quem pediu leva o valor anterior (2)');
}
// --- reraise
{
  const s=T.create('paulista'); const f=s.hand.turn, o=f==='a'?'b':'a';
  T.act(s,f,{a:'raise'});                 // pede 3
  assert(T.act(s,o,{a:'reraise'}).ok);    // aceita 3 e pede 6
  assert.strictEqual(s.hand.points,3); assert.deepStrictEqual(s.hand.pending,{from:o,value:6});
  T.act(s,f,{a:'run'}); assert.strictEqual(s.score[o],3); ok('aumentar de volta (3 → 6) e correr entrega 3');
}
// --- mão de 11
{
  const s=T.create('paulista'); s.score.a=11; s.score.b=2; T.nextHand; s.phase='handEnd'; T.nextHand(s);
  const f=s.hand.turn; assert.strictEqual(s.hand.points,3); assert(s.hand.mao11); assert(!T.act(s,f,{a:'raise'}).ok);
  ok('mão de 11: vale 3 e não aceita aumento');
}
// --- partidas completas aleatórias: sempre terminam, placar coerente
function randomPlayer(s,side){
  const h=s.hand, w=T.waiting(s); if(w!==side) return false;
  const v=T.view(s,side).hand;
  if(h.pending){ const r=Math.random(); return T.act(s,side,{a:r<.6?'accept':r<.8?'run':(v.canReraise?'reraise':'accept')}).ok; }
  if(v.canRaise && Math.random()<.2 && T.act(s,side,{a:'raise'}).ok) return true;
  return T.act(s,side,{a:'play',i:Math.floor(Math.random()*h.hands[side].length)}).ok;
}
for(const mode of ['mineiro','paulista']){
  let hands=0;
  for(let g=0;g<400;g++){
    const s=T.create(mode); let guard=0;
    while(s.phase!=='over'&&guard++<5000){
      if(s.phase==='handEnd'){T.nextHand(s);hands++;continue}
      const w=T.waiting(s); assert(w==='a'||w==='b'); assert(randomPlayer(s,w),'ação aleatória válida deve funcionar');
      assert(s.score.a<=12&&s.score.b<=12);
    }
    assert.strictEqual(s.phase,'over'); assert(s.score.a===12||s.score.b===12); assert(s.winner);
  }
  ok(`400 partidas aleatórias completas (${mode}), ${hands} mãos, todas terminam com 12 pontos`);
}
console.log(`truco: ${n} grupos de testes OK`);
