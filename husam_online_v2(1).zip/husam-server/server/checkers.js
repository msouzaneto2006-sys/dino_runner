'use strict';
// Damas brasileiras: 8x8, peça captura para trás, dama "voadora", captura obrigatória pela lei da maioria.
// Lado 'a' = brancas (embaixo, sobem), 'b' = pretas. Casas 0..63 (linha*8+coluna), jogadas nas casas escuras ((r+c)%2===1).
const MODES = ['brasileiras'];
const col = s => (s === 'a' ? 'w' : 'b');
const other = c => (c === 'w' ? 'b' : 'w');
const inb = (r, c) => r >= 0 && r < 8 && c >= 0 && c < 8;
const DIRS = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
const owner = p => (p ? p.toLowerCase() : null);

function create() {
  const board = Array(64).fill(null);
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) if ((r + c) % 2 === 1) { if (r < 3) board[r * 8 + c] = 'b'; else if (r > 4) board[r * 8 + c] = 'w'; }
  return { phase: 'play', winner: null, reason: null, board, turn: 'w', quiet: 0, last: null };
}
// sequências de captura a partir de `from` (peça `p` de cor `me`); `taken` = índices já capturados (continuam no tabuleiro até o fim)
function captures(b, from, p, me, taken, path, caps, out) {
  const [r, c] = [from >> 3, from & 7], king = p === p.toUpperCase();
  let any = false;
  for (const [dr, dc] of DIRS) {
    let R = r + dr, C = c + dc;
    if (king) while (inb(R, C) && (!b[R * 8 + C] || R * 8 + C === path[0])) { R += dr; C += dc; }       // anda até achar peça
    if (!inb(R, C)) continue;
    const idx = R * 8 + C, q = b[idx];
    if (!q || owner(q) === me || taken.has(idx)) continue;                   // só inimigo ainda não capturado
    // casas de pouso: logo depois (peça comum) ou qualquer vazia depois (dama)
    let LR = R + dr, LC = C + dc; const lands = [];
    while (inb(LR, LC) && (!b[LR * 8 + LC] || LR * 8 + LC === path[0])) { lands.push(LR * 8 + LC); if (!king) break; LR += dr; LC += dc; }
    for (const to of lands) {
      any = true;
      const t2 = new Set(taken); t2.add(idx);
      captures(b, to, p, me, t2, path.concat(to), caps.concat(idx), out);
    }
  }
  if (!any && caps.length) out.push({ path, caps });
}
function legal(s, me) {
  const b = s.board, caps = [], simple = [];
  for (let i = 0; i < 64; i++) {
    const p = b[i]; if (!p || owner(p) !== me) continue;
    const out = []; captures(b, i, p, me, new Set(), [i], [], out); caps.push(...out);
    if (!out.length) {
      const [r, c] = [i >> 3, i & 7], king = p === p.toUpperCase();
      for (const [dr, dc] of DIRS) {
        if (!king && dr !== (me === 'w' ? -1 : 1)) continue;
        for (let R = r + dr, C = c + dc; inb(R, C) && !b[R * 8 + C]; R += dr, C += dc) { simple.push({ path: [i, R * 8 + C], caps: [] }); if (!king) break; }
      }
    }
  }
  if (caps.length) { const mx = Math.max(...caps.map(m => m.caps.length)); return caps.filter(m => m.caps.length === mx); }   // lei da maioria
  return simple;
}
function act(s, side, msg) {
  if (s.phase !== 'play') return { ok: false, error: 'Partida encerrada.' };
  const me = col(side);
  if (s.turn !== me) return { ok: false, error: 'Não é a sua vez.' };
  if (!msg || msg.a !== 'move' || !Array.isArray(msg.path) || msg.path.length < 2 || msg.path.length > 20 || !msg.path.every(Number.isInteger)) return { ok: false, error: 'Lance inválido.' };
  const mv = legal(s, me).find(m => m.path.length === msg.path.length && m.path.every((x, i) => x === msg.path[i]));
  if (!mv) return { ok: false, error: 'Lance ilegal (captura é obrigatória e vale a maior).' };
  const from = mv.path[0], to = mv.path[mv.path.length - 1];
  let p = s.board[from]; s.board[from] = null;
  const wasMan = p === p.toLowerCase();
  for (const i of mv.caps) s.board[i] = null;
  const lastRow = me === 'w' ? 0 : 7;
  if (wasMan && (to >> 3) === lastRow) p = p.toUpperCase();     // promove só se termina na última fila
  s.board[to] = p;
  s.quiet = (mv.caps.length || wasMan) ? 0 : s.quiet + 1;
  s.last = { from, to, path: mv.path };
  s.turn = other(me);
  if (!legal(s, s.turn).length) { s.phase = 'over'; s.reason = 'sem_jogadas'; s.winner = side; }
  else if (s.quiet >= 40) { s.phase = 'over'; s.reason = 'empate_20_lances'; s.winner = null; }
  return { ok: true };
}
const waiting = s => (s.phase === 'play' ? (s.turn === 'w' ? 'a' : 'b') : null);
function view(s, side) {
  const me = col(side), mine = s.turn === me && s.phase === 'play';
  return { phase: s.phase, you: me, board: s.board, turn: s.turn === me ? 'me' : 'opp', last: s.last, legal: mine ? legal(s, me).map(m => m.path) : [], winner: s.winner ? (s.winner === side ? 'me' : 'opp') : null, reason: s.reason };
}
module.exports = { MODES, create, act, view, waiting, nextHand() {}, legal };
