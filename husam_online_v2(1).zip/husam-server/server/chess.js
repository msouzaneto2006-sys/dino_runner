'use strict';
// Xadrez completo (roque, en passant, promoção, mate, afogamento, repetição tripla, 50 lances, material insuficiente).
// Lado 'a' = brancas, 'b' = pretas. Casas 0..63, linha 0 = 8ª fileira (topo), brancas embaixo.
const MODES = ['normal'];
const side2col = s => (s === 'a' ? 'w' : 'b');
const other = c => (c === 'w' ? 'b' : 'w');
const rc = i => [i >> 3, i & 7];
const inb = (r, c) => r >= 0 && r < 8 && c >= 0 && c < 8;
const BACK = 'RNBQKBNR';

function create() {
  const board = Array(64).fill(null);
  for (let c = 0; c < 8; c++) { board[c] = 'b' + BACK[c]; board[8 + c] = 'bP'; board[48 + c] = 'wP'; board[56 + c] = 'w' + BACK[c]; }
  const s = { phase: 'play', winner: null, reason: null, board, turn: 'w', castle: { wK: true, wQ: true, bK: true, bQ: true }, ep: null, half: 0, last: null, reps: {}, captured: { w: [], b: [] }, plies: 0 };
  s.reps[key(s)] = 1; return s;
}
function key(s) { return s.board.map(x => x || '-').join('') + s.turn + (s.castle.wK ? 'K' : '') + (s.castle.wQ ? 'Q' : '') + (s.castle.bK ? 'k' : '') + (s.castle.bQ ? 'q' : '') + (s.ep == null ? '' : s.ep); }

function attacked(board, sq, by) {
  const [r, c] = rc(sq);
  const pr = by === 'w' ? r + 1 : r - 1;                                   // peões de `by` atacam na direção oposta
  for (const dc of [-1, 1]) if (inb(pr, c + dc) && board[pr * 8 + c + dc] === by + 'P') return true;
  for (const [dr, dc] of [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]]) { const R = r + dr, C = c + dc; if (inb(R, C) && board[R * 8 + C] === by + 'N') return true; }
  for (const [dr, dc] of [[1, 1], [1, -1], [-1, 1], [-1, -1], [1, 0], [-1, 0], [0, 1], [0, -1]]) {
    const diag = dr !== 0 && dc !== 0;
    for (let R = r + dr, C = c + dc, n = 1; inb(R, C); R += dr, C += dc, n++) {
      const p = board[R * 8 + C]; if (!p) continue;
      if (p[0] === by && (p[1] === 'Q' || (diag ? p[1] === 'B' : p[1] === 'R') || (n === 1 && p[1] === 'K'))) return true;
      break;
    }
  }
  return false;
}
const kingSq = (board, col) => board.indexOf(col + 'K');
const inCheck = (board, col) => attacked(board, kingSq(board, col), other(col));

function pseudo(s, col) {
  const b = s.board, out = [];
  for (let i = 0; i < 64; i++) {
    const p = b[i]; if (!p || p[0] !== col) continue;
    const [r, c] = rc(i), t = p[1];
    if (t === 'P') {
      const d = col === 'w' ? -1 : 1, start = col === 'w' ? 6 : 1, last = col === 'w' ? 0 : 7;
      const add = (to, extra) => { if (rc(to)[0] === last) for (const pr of 'QRBN') out.push({ from: i, to, promo: pr, ...extra }); else out.push({ from: i, to, ...extra }); };
      if (inb(r + d, c) && !b[(r + d) * 8 + c]) { add((r + d) * 8 + c); if (r === start && !b[(r + 2 * d) * 8 + c]) out.push({ from: i, to: (r + 2 * d) * 8 + c, dbl: true }); }
      for (const dc of [-1, 1]) if (inb(r + d, c + dc)) {
        const to = (r + d) * 8 + c + dc, q = b[to];
        if (q && q[0] !== col) add(to, { cap: true }); else if (!q && s.ep === to) out.push({ from: i, to, ep: true, cap: true });
      }
    } else if (t === 'N' || t === 'K') {
      const ds = t === 'N' ? [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]] : [[1, 1], [1, -1], [-1, 1], [-1, -1], [1, 0], [-1, 0], [0, 1], [0, -1]];
      for (const [dr, dc] of ds) { const R = r + dr, C = c + dc; if (!inb(R, C)) continue; const q = b[R * 8 + C]; if (!q || q[0] !== col) out.push({ from: i, to: R * 8 + C, cap: !!q }); }
      if (t === 'K') {
        const row = col === 'w' ? 7 : 0, o = other(col);
        if (i === row * 8 + 4 && !inCheck(b, col)) {
          if (s.castle[col + 'K'] && !b[row * 8 + 5] && !b[row * 8 + 6] && b[row * 8 + 7] === col + 'R' && !attacked(b, row * 8 + 5, o) && !attacked(b, row * 8 + 6, o)) out.push({ from: i, to: row * 8 + 6, castle: 'K' });
          if (s.castle[col + 'Q'] && !b[row * 8 + 3] && !b[row * 8 + 2] && !b[row * 8 + 1] && b[row * 8] === col + 'R' && !attacked(b, row * 8 + 3, o) && !attacked(b, row * 8 + 2, o)) out.push({ from: i, to: row * 8 + 2, castle: 'Q' });
        }
      }
    } else {
      const ds = [];
      if (t !== 'R') ds.push([1, 1], [1, -1], [-1, 1], [-1, -1]);
      if (t !== 'B') ds.push([1, 0], [-1, 0], [0, 1], [0, -1]);
      for (const [dr, dc] of ds) for (let R = r + dr, C = c + dc; inb(R, C); R += dr, C += dc) { const q = b[R * 8 + C]; if (q) { if (q[0] !== col) out.push({ from: i, to: R * 8 + C, cap: true }); break; } out.push({ from: i, to: R * 8 + C }); }
    }
  }
  return out;
}
function applyMove(s, m) {                         // aplica numa cópia leve (board + castle + ep)
  const b = s.board.slice(), col = b[m.from][0];
  let p = b[m.from]; b[m.from] = null;
  if (m.ep) b[m.to + (col === 'w' ? 8 : -8)] = null;
  if (m.promo) p = col + m.promo;
  b[m.to] = p;
  if (m.castle) { const row = col === 'w' ? 7 : 0; if (m.castle === 'K') { b[row * 8 + 5] = b[row * 8 + 7]; b[row * 8 + 7] = null; } else { b[row * 8 + 3] = b[row * 8]; b[row * 8] = null; } }
  return b;
}
function legal(s, col) { return pseudo(s, col).filter(m => !inCheck(applyMove(s, m), col)); }

function insufficient(b) {
  const ps = b.filter(Boolean).filter(p => p[1] !== 'K');
  if (!ps.length) return true;
  if (ps.some(p => p[1] === 'P' || p[1] === 'R' || p[1] === 'Q')) return false;
  if (ps.length === 1) return true;                                          // K+B ou K+N
  if (ps.every(p => p[1] === 'B')) { const sq = new Set(); b.forEach((p, i) => { if (p && p[1] === 'B') sq.add(((i >> 3) + (i & 7)) & 1); }); return sq.size === 1; }
  return false;
}

function act(s, side, msg) {
  if (s.phase !== 'play') return { ok: false, error: 'Partida encerrada.' };
  const col = side2col(side);
  if (s.turn !== col) return { ok: false, error: 'Não é a sua vez.' };
  if (!msg || msg.a !== 'move') return { ok: false, error: 'Ação inválida.' };
  const from = msg.from | 0, to = msg.to | 0;
  if (!Number.isInteger(msg.from) || !Number.isInteger(msg.to) || from < 0 || from > 63 || to < 0 || to > 63) return { ok: false, error: 'Lance inválido.' };
  const cands = legal(s, col).filter(m => m.from === from && m.to === to);
  if (!cands.length) return { ok: false, error: 'Lance ilegal.' };
  let m = cands[0];
  if (cands.length > 1) { const want = 'QRBN'.includes(msg.promo) ? msg.promo : 'Q'; m = cands.find(x => x.promo === want) || cands[0]; }
  const piece = s.board[m.from], target = m.ep ? s.board[m.to + (col === 'w' ? 8 : -8)] : s.board[m.to];
  if (target) s.captured[col].push(target[1]);
  s.board = applyMove(s, m);
  // direitos de roque
  const rm = sq => { if (sq === 60 || sq === 63) s.castle.wK = sq === 60 ? false : s.castle.wK; };
  if (piece === 'wK') { s.castle.wK = s.castle.wQ = false; } if (piece === 'bK') { s.castle.bK = s.castle.bQ = false; }
  for (const sq of [m.from, m.to]) { if (sq === 63) s.castle.wK = false; if (sq === 56) s.castle.wQ = false; if (sq === 7) s.castle.bK = false; if (sq === 0) s.castle.bQ = false; }
  void rm;
  s.ep = m.dbl ? (m.from + m.to) / 2 : null;
  s.half = (piece[1] === 'P' || target) ? 0 : s.half + 1;
  s.last = { from: m.from, to: m.to }; s.plies++;
  s.turn = other(col);
  const k = key(s); s.reps[k] = (s.reps[k] || 0) + 1;
  const replies = legal(s, s.turn), chk = inCheck(s.board, s.turn);
  s.check = chk;
  if (!replies.length) { s.phase = 'over'; s.reason = chk ? 'mate' : 'stalemate'; s.winner = chk ? side : null; }
  else if (insufficient(s.board)) { s.phase = 'over'; s.reason = 'material'; s.winner = null; }
  else if (s.reps[k] >= 3) { s.phase = 'over'; s.reason = 'repetition'; s.winner = null; }
  else if (s.half >= 100) { s.phase = 'over'; s.reason = 'fifty'; s.winner = null; }
  return { ok: true };
}
const waiting = s => (s.phase === 'play' ? (s.turn === 'w' ? 'a' : 'b') : null);
function view(s, side) {
  const col = side2col(side), mine = s.turn === col && s.phase === 'play';
  return {
    phase: s.phase, you: col, board: s.board, turn: s.turn === col ? 'me' : 'opp', check: !!s.check && s.phase === 'play', last: s.last,
    legal: mine ? legal(s, col).map(m => [m.from, m.to, m.promo || 0]) : [],
    captured: { me: s.captured[col], opp: s.captured[other(col)] },
    winner: s.winner ? (s.winner === side ? 'me' : 'opp') : null, reason: s.reason, plies: s.plies
  };
}
module.exports = { MODES, create, act, view, waiting, nextHand() {}, legal, key };
