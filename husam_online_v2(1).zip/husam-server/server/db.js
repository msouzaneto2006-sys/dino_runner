'use strict';
// Banco SQLite embutido no Node (node:sqlite). Tudo síncrono: cada transação é atômica
// e não existe corrida entre duas operações de dinheiro.
const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');
const path = require('path');

class UserError extends Error {}           // erro "esperado", mensagem segura para mostrar ao usuário

const DEFAULT_SETTINGS = {
  min_deposit_cents: 1000,                 // R$ 10,00
  max_deposit_cents: 500000,               // R$ 5.000,00
  min_withdraw_cents: 2000,                // R$ 20,00
  rake_percent: 0,                         // taxa da casa sobre o pote (0 a 30)
  turn_seconds: 60,                        // tempo para jogar antes de perder por tempo
  stakes: '[100,200,500,1000,2000,2500,5000,10000]'
};

function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  db.exec(`
  CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    username_lc TEXT NOT NULL UNIQUE,
    pass_salt TEXT NOT NULL,
    pass_hash TEXT NOT NULL,
    is_admin INTEGER NOT NULL DEFAULT 0,
    balance_cents INTEGER NOT NULL DEFAULT 0 CHECK(balance_cents >= 0),
    created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS sessions(
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS ledger(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    type TEXT NOT NULL,
    amount_cents INTEGER NOT NULL,
    balance_after INTEGER NOT NULL,
    ref_type TEXT,
    ref_id INTEGER,
    note TEXT,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS ledger_user ON ledger(user_id, id);
  CREATE TABLE IF NOT EXISTS deposit_requests(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
    status TEXT NOT NULL DEFAULT 'pending',
    note TEXT,
    created_at INTEGER NOT NULL,
    decided_at INTEGER,
    decided_by INTEGER
  );
  CREATE TABLE IF NOT EXISTS withdraw_requests(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
    destination TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    note TEXT,
    created_at INTEGER NOT NULL,
    decided_at INTEGER,
    decided_by INTEGER
  );
  CREATE TABLE IF NOT EXISTS matches(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    game TEXT NOT NULL,
    mode TEXT,
    stake_cents INTEGER NOT NULL,
    rake_cents INTEGER NOT NULL DEFAULT 0,
    p1 INTEGER NOT NULL REFERENCES users(id),
    p2 INTEGER NOT NULL REFERENCES users(id),
    status TEXT NOT NULL DEFAULT 'active',
    winner INTEGER,
    reason TEXT,
    created_at INTEGER NOT NULL,
    finished_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
  `);
  const ins = db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)');
  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) ins.run(k, String(v));
  return db;
}

let depth = 0;
function tx(db, fn) {
  if (depth > 0) return fn();              // já dentro de uma transação
  db.exec('BEGIN IMMEDIATE');
  depth++;
  try {
    const r = fn();
    db.exec('COMMIT');
    return r;
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch (_) {}
    throw e;
  } finally { depth--; }
}

function getSettings(db) {
  const rows = db.prepare('SELECT key,value FROM settings').all();
  const m = {}; for (const r of rows) m[r.key] = r.value;
  let stakes = [];
  try { stakes = JSON.parse(m.stakes).map(Number).filter(n => Number.isInteger(n) && n > 0); } catch (_) {}
  if (!stakes.length) stakes = JSON.parse(DEFAULT_SETTINGS.stakes);
  return {
    minDepositCents: +m.min_deposit_cents, maxDepositCents: +m.max_deposit_cents,
    minWithdrawCents: +m.min_withdraw_cents, rakePercent: +m.rake_percent,
    turnSeconds: +m.turn_seconds, stakes
  };
}

const SETTING_LIMITS = {
  min_deposit_cents: [100, 10000000], max_deposit_cents: [100, 10000000],
  min_withdraw_cents: [100, 10000000], rake_percent: [0, 30], turn_seconds: [15, 600]
};
function setSetting(db, key, value) {
  if (key === 'stakes') {
    const arr = Array.isArray(value) ? value.map(Number) : [];
    if (!arr.length || arr.some(n => !Number.isInteger(n) || n < 100 || n > 1000000)) throw new UserError('Apostas inválidas (centavos, de 100 a 1000000).');
    db.prepare('UPDATE settings SET value=? WHERE key=?').run(JSON.stringify([...new Set(arr)].sort((a, b) => a - b)), key);
    return;
  }
  const lim = SETTING_LIMITS[key];
  if (!lim) throw new UserError('Configuração desconhecida.');
  const n = Number(value);
  if (!Number.isFinite(n) || n < lim[0] || n > lim[1]) throw new UserError(`Valor fora do limite (${lim[0]} a ${lim[1]}).`);
  db.prepare('UPDATE settings SET value=? WHERE key=?').run(String(Math.round(n * 100) / 100), key);
}

module.exports = { openDb, tx, getSettings, setSetting, UserError, DEFAULT_SETTINGS };
