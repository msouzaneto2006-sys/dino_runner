'use strict';
const crypto = require('crypto');
const { tx, UserError } = require('./db');
const now = () => Date.now();
const DAY = 86400000;
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const USER_RE = /^[A-Za-z0-9_.]{3,20}$/;

function hashPw(pw, saltHex) {
  return crypto.scryptSync(pw, Buffer.from(saltHex, 'hex'), 32, { N: 16384, r: 8, p: 1 }).toString('hex');
}
function checkPw(pw, saltHex, hashHex) {
  const a = Buffer.from(hashPw(pw, saltHex), 'hex'), b = Buffer.from(hashHex, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const DUMMY_SALT = crypto.randomBytes(16).toString('hex');

function publicUser(u) { return { id: u.id, username: u.username, isAdmin: !!u.is_admin, balance: u.balance_cents }; }

function createUser(db, username, password, isAdmin = false) {
  username = String(username || '').trim(); password = String(password || '');
  if (!USER_RE.test(username)) throw new UserError('Usuário: 3 a 20 caracteres, só letras, números, ponto ou _.');
  if (password.length < 6 || password.length > 64) throw new UserError('A senha precisa ter de 6 a 64 caracteres.');
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = hashPw(password, salt);
  try {
    const r = db.prepare('INSERT INTO users(username,username_lc,pass_salt,pass_hash,is_admin,created_at) VALUES(?,?,?,?,?,?)')
      .run(username, username.toLowerCase(), salt, hash, isAdmin ? 1 : 0, now());
    return db.prepare('SELECT * FROM users WHERE id=?').get(Number(r.lastInsertRowid));
  } catch (e) {
    if (/UNIQUE/i.test(String(e.message))) throw new UserError('Esse usuário já existe. Escolha outro ou entre.');
    throw e;
  }
}

function newSession(db, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions(token_hash,user_id,created_at,expires_at) VALUES(?,?,?,?)').run(sha(token), userId, now(), now() + 30 * DAY);
  return token;
}
function userByToken(db, token) {
  if (!token || typeof token !== 'string' || token.length > 100) return null;
  return db.prepare(`SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?`).get(sha(token), now()) || null;
}
function endSession(db, token) { db.prepare('DELETE FROM sessions WHERE token_hash=?').run(sha(String(token || ''))); }

// ---- limites de tentativas (memória do processo)
const fails = new Map();     // chave -> {n, until}
const regs = new Map();      // ip -> [timestamps]
function checkLock(key) {
  const f = fails.get(key);
  if (f && f.until > now()) return Math.ceil((f.until - now()) / 1000);
  return 0;
}
function noteFail(key, limit) {
  const f = fails.get(key) || { n: 0, until: 0 };
  if (f.until && f.until <= now()) { f.n = 0; f.until = 0; }
  f.n++;
  if (f.n >= limit) { f.until = now() + 60000; f.n = 0; }
  fails.set(key, f);
}
const noteOk = key => fails.delete(key);

function register(db, ip, username, password) {
  const list = (regs.get(ip) || []).filter(t => t > now() - 3600000);
  if (list.length >= 10) throw new UserError('Muitas contas criadas deste aparelho. Tente mais tarde.');
  const u = createUser(db, username, password, false);
  list.push(now()); regs.set(ip, list);
  return { user: u, token: newSession(db, u.id) };
}
function login(db, ip, username, password) {
  username = String(username || '').trim(); password = String(password || '');
  const lc = username.toLowerCase();
  const k1 = 'u:' + lc, k2 = 'i:' + ip;
  const wait = Math.max(checkLock(k1), checkLock(k2));
  if (wait) throw new UserError(`Muitas tentativas. Aguarde ${wait}s.`);
  const u = db.prepare('SELECT * FROM users WHERE username_lc=?').get(lc);
  const ok = u ? checkPw(password, u.pass_salt, u.pass_hash) : (hashPw(password, DUMMY_SALT), false);   // custo igual p/ não vazar se o usuário existe
  if (!ok) { noteFail(k1, 5); noteFail(k2, 40); throw new UserError('Usuário ou senha incorretos.'); }
  noteOk(k1);
  return { user: u, token: newSession(db, u.id) };
}

function seedAdmin(db, username, password) {
  if (!username || !password) return null;
  const lc = String(username).toLowerCase();
  const u = db.prepare('SELECT * FROM users WHERE username_lc=?').get(lc);
  if (u) { if (!u.is_admin) db.prepare('UPDATE users SET is_admin=1 WHERE id=?').run(u.id); return u.id; }
  if (String(password).length < 8) throw new Error('ADMIN_PASSWORD precisa ter pelo menos 8 caracteres.');
  return createUser(db, username, password, true).id;
}
function purgeExpired(db) { db.prepare('DELETE FROM sessions WHERE expires_at<?').run(now()); }

module.exports = { register, login, userByToken, endSession, publicUser, seedAdmin, purgeExpired, USER_RE };
