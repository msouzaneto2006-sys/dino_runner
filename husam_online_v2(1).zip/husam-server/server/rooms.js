'use strict';
// Fila, salas e partidas 1x1. Aposta retida ao começar, paga ao vencedor ao terminar.
const { tx, getSettings, UserError } = require('./db');
const W = require('./wallet');
const A = require('./auth');
const Truco = require('./truco'), Chess = require('./chess'), Checkers = require('./checkers'), Uno = require('./uno'), Blackjack = require('./blackjack'), Pool = require('./pool');

// turnMul: multiplica o tempo de jogada configurado (xadrez pensa mais)
const ENGINES = {
  truco: { engine: Truco, modes: Truco.MODES, turnMul: 1 },
  xadrez: { engine: Chess, modes: Chess.MODES, turnMul: 2 },
  damas: { engine: Checkers, modes: Checkers.MODES, turnMul: 1.5 },
  uno: { engine: Uno, modes: Uno.MODES, turnMul: 1 },
  vinteum: { engine: Blackjack, modes: Blackjack.MODES, turnMul: 1 },
  sinuca: { engine: Pool, modes: Pool.MODES, turnMul: 1.5 }
};
const PAUSE_MS = +process.env.HUSAM_PAUSE_MS || 3500;
const now = () => Date.now();

class Hub {
  constructor(db, log = () => {}) {
    this.db = db; this.log = log;
    this.conns = new Map();        // userId -> Conn
    this.queues = new Map();       // "game|mode|stake" -> [{userId, username}]
    this.userQueue = new Map();    // userId -> key
    this.matches = new Map();      // matchId -> match
    this.userMatch = new Map();    // userId -> matchId
    this.recover();
    this.pinger = setInterval(() => this.heartbeat(), 25000); this.pinger.unref();
  }
  close() { clearInterval(this.pinger); for (const m of this.matches.values()) { clearTimeout(m.timer); clearTimeout(m.pause); } }

  // Partidas que ficaram ativas por queda do servidor: devolve a aposta aos dois.
  recover() {
    const rows = this.db.prepare("SELECT * FROM matches WHERE status='active'").all();
    for (const m of rows) {
      tx(this.db, () => {
        this.db.prepare("UPDATE matches SET status='aborted', reason='server_restart', finished_at=? WHERE id=? AND status='active'").run(now(), m.id);
        for (const uid of [m.p1, m.p2]) W.adjust(this.db, uid, m.stake_cents, 'match_refund', { refType: 'match', refId: m.id, note: 'servidor reiniciou' });
      });
      this.log('recuperada partida ativa', m.id);
    }
  }
  heartbeat() {
    for (const c of this.conns.values()) {
      if (!c.alive) { c.close(1001); continue; }
      c.alive = false; c.ping();
    }
  }

  attach(conn) {
    conn.user = null; conn.msgs = []; 
    conn.on('message', raw => { try { this.onMessage(conn, raw); } catch (e) { this.log('erro msg', e && e.stack || e); conn.send({ t: 'err', msg: 'Erro interno.' }); } });
    conn.on('close', () => this.onClose(conn));
    setTimeout(() => { if (!conn.user && !conn.closed) conn.close(1008); }, 10000).unref();   // precisa autenticar em 10s
  }

  counts() { const o = {}; for (const [k, q] of this.queues) if (q.length) o[k] = q.length; return o; }
  broadcastQueues() { const c = this.counts(); for (const cn of this.conns.values()) cn.send({ t: 'queues', counts: c }); }
  config() { const s = getSettings(this.db); return { stakes: s.stakes, rakePercent: s.rakePercent, turnSeconds: s.turnSeconds, minDepositCents: s.minDepositCents, minWithdrawCents: s.minWithdrawCents, games: Object.fromEntries(Object.entries(ENGINES).map(([k, v]) => [k, { modes: v.modes, turnSeconds: Math.round(s.turnSeconds * v.turnMul) }])) }; }
  sendBalance(userId) { const c = this.conns.get(userId); if (c) c.send({ t: 'balance', balance: W.balanceOf(this.db, userId) }); }

  onMessage(conn, raw) {
    const t0 = now(); conn.msgs = conn.msgs.filter(t => t > t0 - 5000); conn.msgs.push(t0);
    if (conn.msgs.length > 40) return conn.close(1008);
    let m; try { m = JSON.parse(raw); } catch (_) { return; }
    if (!m || typeof m !== 'object') return;
    if (m.t === 'ping') return conn.send({ t: 'pong' });
    if (m.t === 'auth') return this.auth(conn, m.token);
    if (!conn.user) return conn.send({ t: 'auth_fail' });
    const uid = conn.user.id;
    switch (m.t) {
      case 'queue': return this.joinQueue(conn, m);
      case 'cancel': return this.leaveQueue(uid, true);
      case 'act': return this.act(conn, m);
      case 'forfeit': { const mm = this.matches.get(this.userMatch.get(uid)); if (mm) this.finish(mm, mm.sideOf(uid) === 'a' ? 'b' : 'a', 'forfeit'); return; }
    }
  }

  auth(conn, token) {
    const u = A.userByToken(this.db, token);
    if (!u) { conn.send({ t: 'auth_fail' }); return conn.close(1008); }
    const old = this.conns.get(u.id);
    if (old && old !== conn) { old.send({ t: 'replaced' }); old.user = null; old.close(1000); }
    conn.user = { id: u.id, username: u.username, isAdmin: !!u.is_admin };
    this.conns.set(u.id, conn);
    conn.send({ t: 'hello', me: { id: u.id, username: u.username, isAdmin: !!u.is_admin, balance: u.balance_cents }, config: this.config(), queues: this.counts(), queued: this.userQueue.get(u.id) || null });
    const mm = this.matches.get(this.userMatch.get(u.id));
    if (mm) { conn.send(mm.matchMsg(u.id)); this.sendState(mm, u.id); }
  }

  onClose(conn) {
    if (!conn.user) return;
    const uid = conn.user.id;
    if (this.conns.get(uid) === conn) this.conns.delete(uid);
    else return;
    this.leaveQueue(uid, false);
    // numa partida: continua valendo; o relógio de jogada decide se não voltar a tempo
  }

  joinQueue(conn, m) {
    const uid = conn.user.id, s = getSettings(this.db);
    const game = String(m.game || ''), mode = String(m.mode || ''), stake = Number(m.stake);
    const eng = ENGINES[game];
    if (!eng) return conn.send({ t: 'err', msg: 'Esse jogo ainda não está disponível online.' });
    if (!eng.modes.includes(mode)) return conn.send({ t: 'err', msg: 'Modo inválido.' });
    if (!s.stakes.includes(stake)) return conn.send({ t: 'err', msg: 'Valor de aposta inválido.' });
    if (this.userMatch.has(uid)) return conn.send({ t: 'err', msg: 'Você já está em uma partida.' });
    if (this.userQueue.has(uid)) return conn.send({ t: 'err', msg: 'Você já está procurando adversário.' });
    if (W.balanceOf(this.db, uid) < stake) return conn.send({ t: 'err', msg: 'Saldo insuficiente para essa aposta.' });
    const key = `${game}|${mode}|${stake}`;
    const q = this.queues.get(key) || []; this.queues.set(key, q);
    const waiting = q.findIndex(e => e.userId !== uid && this.conns.has(e.userId));
    if (waiting >= 0) {
      const other = q[waiting];
      const ok = this.startMatch({ game, mode, stake }, other, { userId: uid, username: conn.user.username }, key);
      if (ok) return;
      // se falhou, quem estava sem saldo já foi removido; tenta entrar na fila normalmente
      if (this.userQueue.has(uid) || this.userMatch.has(uid)) return;
      if (W.balanceOf(this.db, uid) < stake) return conn.send({ t: 'err', msg: 'Saldo insuficiente para essa aposta.' });
    }
    const q2 = this.queues.get(key) || []; this.queues.set(key, q2);          // a fila pode ter mudado acima
    q2.push({ userId: uid, username: conn.user.username }); this.userQueue.set(uid, key);
    conn.send({ t: 'queued', key, game, mode, stake });
    this.broadcastQueues();
  }

  leaveQueue(uid, notify) {
    const key = this.userQueue.get(uid); if (!key) return;
    const q = (this.queues.get(key) || []).filter(e => e.userId !== uid);
    if (q.length) this.queues.set(key, q); else this.queues.delete(key);
    this.userQueue.delete(uid);
    if (notify) { const c = this.conns.get(uid); if (c) c.send({ t: 'unqueued' }); }
    this.broadcastQueues();
  }

  startMatch(cfg, e1, e2, key) {
    const s = getSettings(this.db), stake = cfg.stake;
    const rake = Math.floor(2 * stake * s.rakePercent / 100);
    let id;
    try {
      id = tx(this.db, () => {
        for (const e of [e1, e2]) if (W.balanceOf(this.db, e.userId) < stake) { const err = new UserError('Saldo insuficiente.'); err.who = e.userId; throw err; }
        const r = this.db.prepare('INSERT INTO matches(game,mode,stake_cents,rake_cents,p1,p2,created_at) VALUES(?,?,?,?,?,?,?)').run(cfg.game, cfg.mode, stake, rake, e1.userId, e2.userId, now());
        const mid = Number(r.lastInsertRowid);
        for (const e of [e1, e2]) W.adjust(this.db, e.userId, -stake, 'match_stake', { refType: 'match', refId: mid });
        return mid;
      });
    } catch (err) {
      if (err instanceof UserError && err.who) {
        const c = this.conns.get(err.who); if (c) c.send({ t: 'err', msg: 'Saldo insuficiente para essa aposta.' });
        if (err.who === e1.userId) this.leaveQueue(e1.userId, true);   // o que estava na fila e ficou sem saldo sai
        return false;
      }
      throw err;
    }
    this.leaveQueue(e1.userId, false);
    const flip = Math.random() < 0.5, pa = flip ? e1 : e2, pb = flip ? e2 : e1;
    const eng = ENGINES[cfg.game].engine;
    const m = {
      id, game: cfg.game, mode: cfg.mode, stake, rake, rakePercent: s.rakePercent, turnSeconds: Math.round(s.turnSeconds * ENGINES[cfg.game].turnMul),
      eng, state: eng.create(cfg.mode), players: { a: pa, b: pb }, timer: null, pause: null, deadline: null, finished: false,
      sideOf(uid) { return pa.userId === uid ? 'a' : 'b'; },
      matchMsg(uid) {
        const side = this.sideOf(uid), opp = this.players[side === 'a' ? 'b' : 'a'];
        return { t: 'match', matchId: id, game: this.game, mode: this.mode, stake, pot: 2 * stake, rake, rakePercent: this.rakePercent, you: side, opp: { username: opp.username }, turnSeconds: this.turnSeconds };
      }
    };
    this.matches.set(id, m); this.userMatch.set(pa.userId, id); this.userMatch.set(pb.userId, id);
    this.broadcastQueues();
    for (const p of [pa, pb]) { this.sendBalance(p.userId); const c = this.conns.get(p.userId); if (c) c.send(m.matchMsg(p.userId)); }
    this.afterChange(m);
    this.log('partida', id, cfg.game, cfg.mode, stake, pa.username, 'x', pb.username);
    return true;
  }

  sendState(m, uid) {
    const c = this.conns.get(uid); if (!c) return;
    c.send({ t: 'state', matchId: m.id, view: m.eng.view(m.state, m.sideOf(uid)), deadline: m.deadline, serverTime: now() });
  }
  broadcast(m) { for (const side of ['a', 'b']) this.sendState(m, m.players[side].userId); }

  // depois de qualquer mudança: relógio, pausa entre mãos, fim da partida
  afterChange(m) {
    clearTimeout(m.timer); m.deadline = null;
    const ph = m.state.phase;
    if (ph === 'over') { this.broadcast(m); return this.finish(m, m.state.winner, 'normal'); }
    if (ph === 'handEnd') {
      this.broadcast(m);
      clearTimeout(m.pause);
      m.pause = setTimeout(() => { if (m.finished) return; m.eng.nextHand(m.state); this.afterChange(m); }, PAUSE_MS);
      return;
    }
    const w = m.eng.waiting(m.state);
    if (w) {
      const extra = m.state.extraMs || 0; m.state.extraMs = 0;            // tempo de animação (sinuca) não conta contra o jogador
      m.deadline = now() + m.turnSeconds * 1000 + extra;
      m.timer = setTimeout(() => { if (!m.finished) this.finish(m, w === 'a' ? 'b' : 'a', 'timeout'); }, m.turnSeconds * 1000 + extra);
    }
    this.broadcast(m);
  }

  act(conn, msg) {
    const uid = conn.user.id, m = this.matches.get(this.userMatch.get(uid));
    if (!m || m.finished) return conn.send({ t: 'err', msg: 'Você não está em uma partida.' });
    const r = m.eng.act(m.state, m.sideOf(uid), msg);
    if (!r.ok) { conn.send({ t: 'err', msg: r.error }); return this.sendState(m, uid); }
    this.afterChange(m);
  }

  // winnerSide: 'a' | 'b' | null (empate = devolve as apostas)
  finish(m, winnerSide, reason) {
    if (m.finished) return; m.finished = true;
    clearTimeout(m.timer); clearTimeout(m.pause);
    let payout = 0;
    try {
      tx(this.db, () => {
        const up = this.db.prepare("UPDATE matches SET status='finished', winner=?, reason=?, finished_at=? WHERE id=? AND status='active'")
          .run(winnerSide ? m.players[winnerSide].userId : null, reason, now(), m.id);
        if (Number(up.changes) !== 1) return;                         // já finalizada (nunca paga duas vezes)
        if (winnerSide) {
          payout = 2 * m.stake - m.rake;
          W.adjust(this.db, m.players[winnerSide].userId, payout, 'match_win', { refType: 'match', refId: m.id, note: reason });
        } else {
          for (const side of ['a', 'b']) W.adjust(this.db, m.players[side].userId, m.stake, 'match_refund', { refType: 'match', refId: m.id, note: 'empate' });
        }
      });
    } catch (e) { this.log('ERRO ao pagar partida', m.id, e); }
    for (const side of ['a', 'b']) {
      const uid = m.players[side].userId, c = this.conns.get(uid);
      this.userMatch.delete(uid);
      if (c) c.send({ t: 'end', matchId: m.id, result: winnerSide ? (side === winnerSide ? 'win' : 'lose') : 'draw', reason, payout: side === winnerSide ? payout : (winnerSide ? 0 : m.stake), balance: W.balanceOf(this.db, uid) });
    }
    this.matches.delete(m.id);
    this.log('fim', m.id, reason, winnerSide);
  }
}
module.exports = { Hub };
