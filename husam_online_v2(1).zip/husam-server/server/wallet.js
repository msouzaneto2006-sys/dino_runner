'use strict';
// Carteira em centavos (inteiros). Toda alteração de saldo passa por adjust() e gera uma linha no ledger.
const { tx, getSettings, UserError } = require('./db');
const now = () => Date.now();

// Deve ser chamada DENTRO de tx().
function adjust(db, userId, delta, type, o = {}) {
  if (!Number.isInteger(delta)) throw new Error('valor inválido');
  const u = db.prepare('SELECT balance_cents FROM users WHERE id=?').get(userId);
  if (!u) throw new UserError('Usuário não encontrado.');
  const nb = u.balance_cents + delta;
  if (nb < 0) throw new UserError('Saldo insuficiente.');
  db.prepare('UPDATE users SET balance_cents=? WHERE id=?').run(nb, userId);
  db.prepare('INSERT INTO ledger(user_id,type,amount_cents,balance_after,ref_type,ref_id,note,created_at) VALUES(?,?,?,?,?,?,?,?)')
    .run(userId, type, delta, nb, o.refType || null, o.refId || null, o.note || null, now());
  return nb;
}
const balanceOf = (db, userId) => (db.prepare('SELECT balance_cents b FROM users WHERE id=?').get(userId) || {}).b;

function cleanCents(v) {
  const n = Number(v);
  if (!Number.isInteger(n) || n <= 0) throw new UserError('Valor inválido.');
  return n;
}

function requestDeposit(db, userId, cents) {
  cents = cleanCents(cents);
  const s = getSettings(db);
  if (cents < s.minDepositCents) throw new UserError(`Depósito mínimo: ${brl(s.minDepositCents)}.`);
  if (cents > s.maxDepositCents) throw new UserError(`Depósito máximo: ${brl(s.maxDepositCents)}.`);
  return tx(db, () => {
    const p = db.prepare("SELECT COUNT(*) c FROM deposit_requests WHERE user_id=? AND status='pending'").get(userId).c;
    if (p >= 3) throw new UserError('Você já tem 3 depósitos aguardando aprovação.');
    const r = db.prepare('INSERT INTO deposit_requests(user_id,amount_cents,created_at) VALUES(?,?,?)').run(userId, cents, now());
    return Number(r.lastInsertRowid);
  });
}

function requestWithdraw(db, userId, cents, destination) {
  cents = cleanCents(cents);
  destination = String(destination || '').trim();
  if (destination.length < 3 || destination.length > 120) throw new UserError('Informe a chave PIX (ou destino) do saque.');
  const s = getSettings(db);
  if (cents < s.minWithdrawCents) throw new UserError(`Saque mínimo: ${brl(s.minWithdrawCents)}.`);
  return tx(db, () => {
    const p = db.prepare("SELECT COUNT(*) c FROM withdraw_requests WHERE user_id=? AND status='pending'").get(userId).c;
    if (p >= 3) throw new UserError('Você já tem 3 saques aguardando aprovação.');
    const r = db.prepare('INSERT INTO withdraw_requests(user_id,amount_cents,destination,created_at) VALUES(?,?,?,?)').run(userId, cents, destination, now());
    const id = Number(r.lastInsertRowid);
    adjust(db, userId, -cents, 'withdraw_hold', { refType: 'withdraw', refId: id });   // valor sai do saldo na hora
    return id;
  });
}

function decideDeposit(db, adminId, id, approve, note) {
  return tx(db, () => {
    const r = db.prepare('SELECT * FROM deposit_requests WHERE id=?').get(id);
    if (!r) throw new UserError('Pedido não encontrado.');
    const up = db.prepare("UPDATE deposit_requests SET status=?, note=?, decided_at=?, decided_by=? WHERE id=? AND status='pending'")
      .run(approve ? 'approved' : 'rejected', note || null, now(), adminId, id);
    if (Number(up.changes) !== 1) throw new UserError('Esse pedido já foi decidido.');
    if (approve) adjust(db, r.user_id, r.amount_cents, 'deposit', { refType: 'deposit', refId: id, note });
    return true;
  });
}

function decideWithdraw(db, adminId, id, approve, note) {
  return tx(db, () => {
    const r = db.prepare('SELECT * FROM withdraw_requests WHERE id=?').get(id);
    if (!r) throw new UserError('Pedido não encontrado.');
    const up = db.prepare("UPDATE withdraw_requests SET status=?, note=?, decided_at=?, decided_by=? WHERE id=? AND status='pending'")
      .run(approve ? 'approved' : 'rejected', note || null, now(), adminId, id);
    if (Number(up.changes) !== 1) throw new UserError('Esse pedido já foi decidido.');
    if (approve) {
      const bal = balanceOf(db, r.user_id);
      db.prepare('INSERT INTO ledger(user_id,type,amount_cents,balance_after,ref_type,ref_id,note,created_at) VALUES(?,?,?,?,?,?,?,?)')
        .run(r.user_id, 'withdraw_paid', 0, bal, 'withdraw', id, note || null, now());
    } else {
      adjust(db, r.user_id, r.amount_cents, 'withdraw_refund', { refType: 'withdraw', refId: id, note });
    }
    return true;
  });
}

function adminAdjust(db, adminId, userId, cents, note) {
  if (!Number.isInteger(cents) || cents === 0) throw new UserError('Valor inválido.');
  note = String(note || '').trim();
  if (note.length < 3) throw new UserError('Escreva um motivo.');
  return tx(db, () => adjust(db, userId, cents, 'admin_adjust', { refType: 'admin', refId: adminId, note }));
}

function recentLedger(db, userId, limit = 30) {
  return db.prepare('SELECT id,type,amount_cents,balance_after,note,created_at FROM ledger WHERE user_id=? ORDER BY id DESC LIMIT ?').all(userId, limit);
}
function userRequests(db, userId) {
  return {
    deposits: db.prepare('SELECT id,amount_cents,status,note,created_at FROM deposit_requests WHERE user_id=? ORDER BY id DESC LIMIT 10').all(userId),
    withdraws: db.prepare('SELECT id,amount_cents,destination,status,note,created_at FROM withdraw_requests WHERE user_id=? ORDER BY id DESC LIMIT 10').all(userId)
  };
}
const brl = c => 'R$ ' + (c / 100).toFixed(2).replace('.', ',');

module.exports = { adjust, balanceOf, requestDeposit, requestWithdraw, decideDeposit, decideWithdraw, adminAdjust, recentLedger, userRequests, brl };
