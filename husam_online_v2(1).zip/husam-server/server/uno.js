'use strict';
// UNO 1x1: 108 cartas, compra 7. Pular/Inverter = joga de novo; +2 e +4 = adversário compra e perde a vez.
const MODES = ['classico'];
const other = s => (s === 'a' ? 'b' : 'a');
function deck() {
  const d = [];
  for (const c of 'RYGB') {
    d.push({ c, v: '0' });
    for (let k = 0; k < 2; k++) { for (const v of '123456789SRD') d.push({ c, v }); }
  }
  for (let k = 0; k < 4; k++) { d.push({ c: 'W', v: 'W' }); d.push({ c: 'W', v: 'F' }); }
  for (let i = d.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [d[i], d[j]] = [d[j], d[i]]; }
  return d;
}
function create() {
  const s = { phase: 'play', winner: null, reason: null, pile: deck(), disc: [], hands: { a: [], b: [] }, turn: Math.random() < 0.5 ? 'a' : 'b', drawn: false, color: null, log: null };
  for (let i = 0; i < 7; i++) { s.hands.a.push(s.pile.pop()); s.hands.b.push(s.pile.pop()); }
  let top; do { top = s.pile.pop(); if (top.c === 'W' || !/[0-9]/.test(top.v)) { s.pile.unshift(top); top = null; } } while (!top);
  s.disc.push(top); s.color = top.c; return s;
}
const top = s => s.disc[s.disc.length - 1];
function playable(s, c) { return c.c === 'W' || c.c === s.color || c.v === top(s).v; }
function draw(s, side, n) {
  for (let i = 0; i < n; i++) {
    if (!s.pile.length) { const t = s.disc.pop(), rest = s.disc; s.disc = [t]; for (let k = rest.length - 1; k > 0; k--) { const j = Math.floor(Math.random() * (k + 1)); [rest[k], rest[j]] = [rest[j], rest[k]]; } s.pile = rest; }
    if (!s.pile.length) return;                        // baralho esgotado (quase impossível)
    s.hands[side].push(s.pile.pop());
  }
}
function act(s, side, msg) {
  if (s.phase !== 'play') return { ok: false, error: 'Partida encerrada.' };
  if (s.turn !== side) return { ok: false, error: 'Não é a sua vez.' };
  if (!msg) return { ok: false, error: 'Ação inválida.' };
  const h = s.hands[side], opp = other(side);
  if (msg.a === 'draw') {
    if (s.drawn) return { ok: false, error: 'Você já comprou: jogue a carta ou passe.' };
    draw(s, side, 1); s.drawn = true; s.log = { who: side, t: 'draw' };
    if (!h.length || !playable(s, h[h.length - 1])) { s.drawn = false; s.turn = opp; s.log = { who: side, t: 'drawpass' }; }
    return { ok: true };
  }
  if (msg.a === 'pass') {
    if (!s.drawn) return { ok: false, error: 'Compre uma carta antes de passar.' };
    s.drawn = false; s.turn = opp; s.log = { who: side, t: 'pass' }; return { ok: true };
  }
  if (msg.a === 'play') {
    const i = msg.i;
    if (!Number.isInteger(i) || i < 0 || i >= h.length) return { ok: false, error: 'Carta inválida.' };
    if (s.drawn && i !== h.length - 1) return { ok: false, error: 'Depois de comprar, só pode jogar a carta comprada.' };
    const c = h[i];
    if (!playable(s, c)) return { ok: false, error: 'Essa carta não combina.' };
    let color = c.c;
    if (c.c === 'W') { if (!'RYGB'.includes(msg.color) || !msg.color) return { ok: false, error: 'Escolha uma cor.' }; color = msg.color; }
    h.splice(i, 1); s.disc.push(c); s.color = color; s.drawn = false;
    s.log = { who: side, t: 'play', card: c, color };
    if (!h.length) { s.phase = 'over'; s.winner = side; s.reason = 'normal'; return { ok: true }; }
    if (c.v === 'D') { draw(s, opp, 2); }                         // adversário compra 2 e perde a vez: jogador joga de novo
    else if (c.v === 'F') { draw(s, opp, 4); }
    else if (c.v === 'S' || c.v === 'R') { /* 2 jogadores: joga de novo */ }
    else s.turn = opp;
    return { ok: true };
  }
  return { ok: false, error: 'Ação inválida.' };
}
const waiting = s => (s.phase === 'play' ? s.turn : null);
function view(s, side) {
  const mine = s.turn === side && s.phase === 'play', h = s.hands[side];
  const lg = s.log ? { who: s.log.who === side ? 'me' : 'opp', t: s.log.t, card: s.log.card, color: s.log.color } : null;
  return {
    phase: s.phase, turn: s.turn === side ? 'me' : 'opp', top: top(s), color: s.color, deck: s.pile.length, oppCount: s.hands[other(side)].length,
    myCards: h.map((c, i) => ({ c: c.c, v: c.v, ok: mine && playable(s, c) && (!s.drawn || i === h.length - 1) })), drawn: mine && s.drawn,
    log: lg, winner: s.winner ? (s.winner === side ? 'me' : 'opp') : null, reason: s.reason
  };
}
module.exports = { MODES, create, act, view, waiting, nextHand() {}, playable };
