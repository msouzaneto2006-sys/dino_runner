'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const { openDb, tx, getSettings, setSetting, UserError } = require('./db');
const A = require('./auth');
const W = require('./wallet');
const { Hub } = require('./rooms');
const { accept } = require('./ws');

const PUBLIC = path.join(__dirname, '..', 'public');
const ASSETS = { '/icon-192.png': ['icon-192.png', 'image/png'], '/icon-512.png': ['icon-512.png', 'image/png'], '/manifest.webmanifest': ['manifest.webmanifest', 'application/manifest+json'] };
const PAGES = { '/': 'index.html', '/index.html': 'index.html', '/admin': 'admin.html', '/admin.html': 'admin.html' };

function createServer(opts = {}) {
  const dataDir = opts.dataDir || process.env.DATA_DIR || path.join(__dirname, '..', 'data');
  const db = openDb(opts.memory ? ':memory:' : path.join(dataDir, 'husam.db'));
  const log = opts.quiet ? () => {} : (...a) => console.log(new Date().toISOString(), ...a);
  const trustProxy = opts.trustProxy ?? process.env.TRUST_PROXY === '1';
  const adminUser = opts.adminUser ?? process.env.ADMIN_USERNAME, adminPass = opts.adminPass ?? process.env.ADMIN_PASSWORD;
  if (adminUser && adminPass) { A.seedAdmin(db, adminUser, adminPass); log('administrador:', adminUser); }
  else log('AVISO: defina ADMIN_USERNAME e ADMIN_PASSWORD para ter um administrador.');
  const hub = new Hub(db, log);
  const purge = setInterval(() => { try { A.purgeExpired(db); } catch (_) {} }, 3600000); purge.unref();

  const ipOf = req => {
    if (trustProxy) { const x = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim(); if (x) return x; }
    return req.socket.remoteAddress || '?';
  };
  const send = (res, code, obj) => {
    const body = JSON.stringify(obj);
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    res.end(body);
  };
  const readJson = req => new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', c => { n += c.length; if (n > 20000) { reject(new UserError('Pedido grande demais.')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (_) { reject(new UserError('JSON inválido.')); } });
    req.on('error', reject);
  });
  const tokenOf = req => { const h = req.headers.authorization || ''; return h.startsWith('Bearer ') ? h.slice(7).trim() : ''; };
  const authed = req => { const u = A.userByToken(db, tokenOf(req)); if (!u) throw Object.assign(new UserError('Sessão expirada. Entre de novo.'), { code: 401 }); return u; };
  const adminOnly = req => { const u = authed(req); if (!u.is_admin) throw Object.assign(new UserError('Sem permissão.'), { code: 403 }); return u; };
  const me = u => A.publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(u.id));

  async function api(req, res, url) {
    const m = req.method, p = url.pathname;
    if (m === 'POST' && p === '/api/register') { const b = await readJson(req); const r = A.register(db, ipOf(req), b.username, b.password); return send(res, 200, { ok: true, token: r.token, user: A.publicUser(r.user) }); }
    if (m === 'POST' && p === '/api/login') { const b = await readJson(req); const r = A.login(db, ipOf(req), b.username, b.password); return send(res, 200, { ok: true, token: r.token, user: A.publicUser(r.user) }); }
    if (m === 'POST' && p === '/api/logout') { A.endSession(db, tokenOf(req)); return send(res, 200, { ok: true }); }
    if (m === 'GET' && p === '/api/health') return send(res, 200, { ok: true });
    if (m === 'GET' && p === '/api/me') { const u = authed(req); return send(res, 200, { ok: true, user: me(u), config: hub.config() }); }
    if (m === 'GET' && p === '/api/wallet') { const u = authed(req); return send(res, 200, { ok: true, balance: me(u).balance, ledger: W.recentLedger(db, u.id), ...W.userRequests(db, u.id), config: hub.config() }); }
    if (m === 'POST' && p === '/api/deposit') { const u = authed(req); const b = await readJson(req); const id = W.requestDeposit(db, u.id, b.amount_cents); return send(res, 200, { ok: true, id }); }
    if (m === 'POST' && p === '/api/withdraw') { const u = authed(req); const b = await readJson(req); const id = W.requestWithdraw(db, u.id, b.amount_cents, b.destination); hub.sendBalance(u.id); return send(res, 200, { ok: true, id, balance: me(u).balance }); }

    // ---------- administrador
    if (p.startsWith('/api/admin/')) {
      const admin = adminOnly(req);
      if (m === 'GET' && p === '/api/admin/overview') {
        const q = s => db.prepare(s).get();
        return send(res, 200, { ok: true,
          pendingDeposits: db.prepare("SELECT d.id,d.amount_cents,d.created_at,u.username FROM deposit_requests d JOIN users u ON u.id=d.user_id WHERE d.status='pending' ORDER BY d.id").all(),
          pendingWithdraws: db.prepare("SELECT w.id,w.amount_cents,w.destination,w.created_at,u.username FROM withdraw_requests w JOIN users u ON u.id=w.user_id WHERE w.status='pending' ORDER BY w.id").all(),
          totals: { users: q('SELECT COUNT(*) c FROM users').c, balances: q('SELECT COALESCE(SUM(balance_cents),0) s FROM users').s, rake: q("SELECT COALESCE(SUM(rake_cents),0) s FROM matches WHERE status='finished'").s, matchesFinished: q("SELECT COUNT(*) c FROM matches WHERE status='finished'").c, matchesActive: hub.matches.size, queued: hub.userQueue.size, online: hub.conns.size },
          settings: getSettings(db) });
      }
      if (m === 'GET' && p === '/api/admin/users') return send(res, 200, { ok: true, users: db.prepare('SELECT id,username,is_admin,balance_cents,created_at FROM users ORDER BY id DESC LIMIT 200').all() });
      if (m === 'GET' && p === '/api/admin/matches') return send(res, 200, { ok: true, matches: db.prepare('SELECT m.*,a.username u1,b.username u2 FROM matches m JOIN users a ON a.id=m.p1 JOIN users b ON b.id=m.p2 ORDER BY m.id DESC LIMIT 50').all() });
      if (m === 'GET' && p === '/api/admin/history') return send(res, 200, { ok: true,
        deposits: db.prepare("SELECT d.id,d.amount_cents,d.status,d.created_at,d.decided_at,u.username FROM deposit_requests d JOIN users u ON u.id=d.user_id WHERE d.status!='pending' ORDER BY d.id DESC LIMIT 30").all(),
        withdraws: db.prepare("SELECT w.id,w.amount_cents,w.destination,w.status,w.created_at,w.decided_at,u.username FROM withdraw_requests w JOIN users u ON u.id=w.user_id WHERE w.status!='pending' ORDER BY w.id DESC LIMIT 30").all() });
      let mm;
      if (m === 'POST' && (mm = p.match(/^\/api\/admin\/(deposit|withdraw)\/(\d+)\/(approve|reject)$/))) {
        const b = await readJson(req), id = +mm[2], ok = mm[3] === 'approve';
        const row = db.prepare(mm[1] === 'deposit' ? 'SELECT user_id FROM deposit_requests WHERE id=?' : 'SELECT user_id FROM withdraw_requests WHERE id=?').get(id);
        (mm[1] === 'deposit' ? W.decideDeposit : W.decideWithdraw)(db, admin.id, id, ok, b.note);
        if (row) hub.sendBalance(row.user_id);
        return send(res, 200, { ok: true });
      }
      if (m === 'POST' && p === '/api/admin/adjust') {
        const b = await readJson(req); const nb = W.adminAdjust(db, admin.id, Number(b.user_id), Number(b.amount_cents), b.note);
        hub.sendBalance(Number(b.user_id)); return send(res, 200, { ok: true, balance: nb });
      }
      if (m === 'POST' && p === '/api/admin/settings') {
        const b = await readJson(req);
        tx(db, () => { for (const [k, v] of Object.entries(b || {})) setSetting(db, k, v); });
        return send(res, 200, { ok: true, settings: getSettings(db) });
      }
    }
    return send(res, 404, { ok: false, error: 'Não encontrado.' });
  }

  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://x');
      res.setHeader('X-Frame-Options', 'DENY'); res.setHeader('Referrer-Policy', 'no-referrer');
      if (url.pathname.startsWith('/api/')) return await api(req, res, url);
      const page = PAGES[url.pathname];
      if (req.method === 'GET' && page) {
        const f = path.join(PUBLIC, page);
        if (!fs.existsSync(f)) { res.writeHead(404); return res.end('Arquivo não encontrado'); }
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
        return res.end(fs.readFileSync(f));
      }
      const asset = ASSETS[url.pathname];
      if (req.method === 'GET' && asset && fs.existsSync(path.join(PUBLIC, asset[0]))) { res.writeHead(200, { 'Content-Type': asset[1], 'Cache-Control': 'public, max-age=86400' }); return res.end(fs.readFileSync(path.join(PUBLIC, asset[0]))); }
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Não encontrado');
    } catch (e) {
      if (e instanceof UserError) return send(res, e.code || 400, { ok: false, error: e.message });
      log('ERRO', e && e.stack || e);
      send(res, 500, { ok: false, error: 'Erro interno.' });
    }
  });
  server.on('upgrade', (req, socket) => {
    if (new URL(req.url, 'http://x').pathname !== '/ws') return socket.destroy();
    const conn = accept(req, socket, process.env.ALLOWED_ORIGIN);
    if (conn) hub.attach(conn);
  });
  server.hub = hub; server.db = db;
  server.shutdown = () => { hub.close(); clearInterval(purge); server.close(); try { db.close(); } catch (_) {} };
  return server;
}

module.exports = { createServer };
if (require.main === module) {
  const port = +process.env.PORT || 3000;
  const s = createServer();
  s.listen(port, '0.0.0.0', () => console.log('HUSAM servidor em http://localhost:' + port));
  const bye = () => { s.shutdown(); process.exit(0); };
  process.on('SIGTERM', bye); process.on('SIGINT', bye);
}
