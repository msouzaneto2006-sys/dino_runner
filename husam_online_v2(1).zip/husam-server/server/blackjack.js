'use strict';
// 21 1x1: cada um recebe 2 cartas (a primeira do adversário fica virada). Pede ou para; estourou perde.
// Quem tiver mais perto de 21 leva a rodada. Melhor de 3 (empates não contam, no máximo 5 rodadas).
const MODES = ['melhor_de_3'];
const other = s => (s === 'a' ? 'b' : 'a');
const MAXH = 5;
function shuffled() {
  const d = []; for (const s of '♠♥♦♣') for (const r of ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']) d.push({ r, s });
  for (let i = d.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [d[i], d[j]] = [d[j], d[i]]; }
  return d;
}
function total(cs) { let t = 0, aces = 0; for (const c of cs) { if (c.r === 'A') { aces++; t += 11; } else t += 'JQK'.includes(c.r) ? 10 : +c.r; } while (t > 21 && aces) { t -= 10; aces--; } return t; }
function deal(s) {
  s.deck = shuffled(); s.hands = { a: [s.deck.pop(), s.deck.pop()], b: [s.deck.pop(), s.deck.pop()] };
  s.stood = { a: false, b: false }; s.turn = s.starter; s.hand = { reveal: false, result: null, reason: null };
  for (const k of ['a', 'b']) if (total(s.hands[k]) === 21) s.stood[k] = true;           // 21 natural: já para
  if (s.stood[s.turn]) s.turn = other(s.turn);
  if (s.stood.a && s.stood.b) resolve(s);
}
function create() {
  const s = { phase: 'play', winner: null, reason: null, handNo: 1, score: { a: 0, b: 0 }, starter: Math.random() < 0.5 ? 'a' : 'b', lastHand: null };
  deal(s); return s;
}
function endHand(s, winner, reason) {                                     // winner: 'a'|'b'|null
  s.hand.reveal = true; s.hand.result = winner; s.hand.reason = reason;
  if (winner) s.score[winner]++;
  s.lastHand = { winner, reason, totals: { a: total(s.hands.a), b: total(s.hands.b) } };
  if (s.score.a >= 2 || s.score.b >= 2) { s.phase = 'over'; s.winner = s.score.a > s.score.b ? 'a' : 'b'; s.reason = 'normal'; }
  else if (s.handNo >= MAXH) { s.phase = 'over'; s.winner = s.score.a === s.score.b ? null : (s.score.a > s.score.b ? 'a' : 'b'); s.reason = 'normal'; }
  else s.phase = 'handEnd';
}
function resolve(s) {
  const ta = total(s.hands.a), tb = total(s.hands.b);
  endHand(s, ta === tb ? null : (ta > tb ? 'a' : 'b'), ta === tb ? 'empate' : 'maior');
}
function nextHand(s) { if (s.phase !== 'handEnd') return; s.handNo++; s.starter = other(s.starter); s.phase = 'play'; deal(s); }
function act(s, side, msg) {
  if (s.phase !== 'play') return { ok: false, error: 'Aguarde a próxima rodada.' };
  if (s.turn !== side) return { ok: false, error: 'Não é a sua vez.' };
  if (!msg || (msg.a !== 'hit' && msg.a !== 'stand')) return { ok: false, error: 'Ação inválida.' };
  const opp = other(side);
  if (msg.a === 'hit') {
    s.hands[side].push(s.deck.pop());
    const t = total(s.hands[side]);
    if (t > 21) { endHand(s, opp, 'estourou'); return { ok: true }; }
    if (t === 21) s.stood[side] = true;
  } else s.stood[side] = true;
  if (s.stood.a && s.stood.b) { resolve(s); return { ok: true }; }
  s.turn = s.stood[opp] ? side : opp;                                       // quem já parou não joga mais
  if (s.stood[s.turn]) { resolve(s); }
  return { ok: true };
}
const waiting = s => (s.phase === 'play' ? s.turn : null);
function view(s, side) {
  const o = other(side), rev = s.hand.reveal;
  return {
    phase: s.phase, handNo: s.handNo, maxHands: MAXH, score: { me: s.score[side], opp: s.score[o] }, turn: s.turn === side ? 'me' : 'opp',
    myCards: s.hands[side], myTotal: total(s.hands[side]), standMe: s.stood[side], standOpp: s.stood[o],
    oppCards: s.hands[o].map((c, i) => (i === 0 && !rev ? null : c)), oppTotal: rev ? total(s.hands[o]) : null,
    reveal: rev, lastHand: s.lastHand ? { winner: s.lastHand.winner ? (s.lastHand.winner === side ? 'me' : 'opp') : null, reason: s.lastHand.reason } : null,
    winner: s.winner ? (s.winner === side ? 'me' : 'opp') : null, reason: s.reason
  };
}
module.exports = { MODES, create, act, view, waiting, nextHand, total };
