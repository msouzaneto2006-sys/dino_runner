'use strict';
// Sinuca 8: física no servidor (mesma do jogo contra a máquina). O cliente só manda ângulo + força;
// o servidor simula a tacada inteira, aplica as regras e manda os quadros para os dois animarem.
const MODES = ['8ball'];
const other = s => (s === 'a' ? 'b' : 'a');
const POCKETS = [[24, 24], [380, 18], [736, 24], [24, 396], [380, 402], [736, 396]];
const MAX_SPEED = 15, MIN_SPEED = 2, MAX_STEPS = 3600, SAMPLE = 2;
const CUE0 = [190, 210];

function rack() {
  const balls = [{ n: 0, x: CUE0[0], y: CUE0[1], vx: 0, vy: 0, r: 10, type: 'cue', dead: false }];
  const nums = [1, 9, 2, 10, 8, 3, 11, 4, 12, 5, 13, 6, 14, 7, 15]; let k = 0;
  for (let row = 0; row < 5; row++) for (let j = 0; j <= row; j++) { const n = nums[k++]; balls.push({ n, x: 535 + row * 18.2, y: 210 - row * 21 / 2 + j * 21, vx: 0, vy: 0, r: 10, type: n === 8 ? 'eight' : n < 8 ? 'solid' : 'stripe', dead: false }); }
  return balls;
}
function create() {
  return { phase: 'play', winner: null, reason: null, balls: rack(), turn: Math.random() < 0.5 ? 'a' : 'b', groups: { a: null, b: null }, hand: false, breakShot: true, seq: 0, shot: null, event: null, extraMs: 0 };
}
function simulate(balls) {
  const frames = [], pots = []; let first = null, rail = false, step = 0;
  const snap = () => { const f = []; for (const b of balls) { f.push(b.dead ? -1 : Math.round(b.x * 10), b.dead ? -1 : Math.round(b.y * 10)); } frames.push(f); };
  snap();
  for (; step < MAX_STEPS; step++) {
    let any = false;
    for (const b of balls) if (!b.dead) {
      b.x += b.vx; b.y += b.vy; b.vx *= .987; b.vy *= .987;
      if (Math.abs(b.vx) < .025) b.vx = 0; if (Math.abs(b.vy) < .025) b.vy = 0; if (b.vx || b.vy) any = true;
      for (const p of POCKETS) if (Math.hypot(b.x - p[0], b.y - p[1]) < 17) { b.dead = true; b.vx = b.vy = 0; pots.push([b.n, frames.length]); break; }
      if (b.dead) continue;
      if (b.x - b.r < 18) { b.x = 18 + b.r; b.vx = Math.abs(b.vx) * .88; if (first) rail = true; }
      if (b.x + b.r > 742) { b.x = 742 - b.r; b.vx = -Math.abs(b.vx) * .88; if (first) rail = true; }
      if (b.y - b.r < 18) { b.y = 18 + b.r; b.vy = Math.abs(b.vy) * .88; if (first) rail = true; }
      if (b.y + b.r > 402) { b.y = 402 - b.r; b.vy = -Math.abs(b.vy) * .88; if (first) rail = true; }
    }
    for (let i = 0; i < balls.length; i++) for (let j = i + 1; j < balls.length; j++) {
      const a = balls[i], b = balls[j]; if (a.dead || b.dead) continue;
      const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy);
      if (d && d < a.r + b.r) {
        const nx = dx / d, ny = dy / d, over = a.r + b.r - d;
        a.x -= nx * over / 2; a.y -= ny * over / 2; b.x += nx * over / 2; b.y += ny * over / 2;
        const rel = (a.vx - b.vx) * nx + (a.vy - b.vy) * ny;
        if (rel > 0) { a.vx -= rel * nx; a.vy -= rel * ny; b.vx += rel * nx; b.vy += rel * ny; }
        if (first === null) { if (a.n === 0) first = b; else if (b.n === 0) first = a; }
        any = true;
      }
    }
    if ((step + 1) % SAMPLE === 0) snap();
    if (!any) break;
  }
  snap();
  return { frames, pots, first, rail, steps: step };
}
function freeSpot(balls) {
  const ok = (x, y) => balls.every(b => b.n === 0 || b.dead || Math.hypot(b.x - x, b.y - y) > 22);
  if (ok(...CUE0)) return CUE0.slice();
  for (let r = 0; r < 340; r += 24) for (let a = 0; a < 360; a += 30) { const x = CUE0[0] + Math.cos(a * Math.PI / 180) * r, y = CUE0[1] + Math.sin(a * Math.PI / 180) * r; if (x > 50 && x < 710 && y > 50 && y < 370 && ok(x, y)) return [x, y]; }
  return CUE0.slice();
}
function act(s, side, msg) {
  if (s.phase !== 'play') return { ok: false, error: 'Partida encerrada.' };
  if (s.turn !== side) return { ok: false, error: 'Não é a sua vez.' };
  if (!msg || msg.a !== 'shoot') return { ok: false, error: 'Ação inválida.' };
  let nx = Number(msg.nx), ny = Number(msg.ny), f = Number(msg.power);
  if (![nx, ny, f].every(Number.isFinite)) return { ok: false, error: 'Tacada inválida.' };
  const l = Math.hypot(nx, ny); if (l < 1e-6) return { ok: false, error: 'Tacada inválida.' };
  nx /= l; ny /= l; f = Math.max(0, Math.min(1, f));
  const cue = s.balls[0];
  if (s.hand && msg.cue && Number.isFinite(msg.cue.x) && Number.isFinite(msg.cue.y) && Math.hypot(msg.cue.x - cue.x, msg.cue.y - cue.y) > 0.5) {   // só valida se a branca foi movida
    const x = msg.cue.x, y = msg.cue.y;
    if (x < 32 + cue.r + 2 || x > 728 - cue.r - 2 || y < 32 + cue.r + 2 || y > 388 - cue.r - 2) return { ok: false, error: 'Posição da branca inválida.' };
    if (s.balls.some(b => b !== cue && !b.dead && Math.hypot(b.x - x, b.y - y) < cue.r + b.r + 1)) return { ok: false, error: 'A branca não pode ficar em cima de outra bola.' };
    cue.x = x; cue.y = y;
  }
  const sp = MIN_SPEED + f * (MAX_SPEED - MIN_SPEED);
  cue.vx = nx * sp; cue.vy = ny * sp; s.hand = false;
  const wasBreak = s.breakShot; s.breakShot = false;
  const sim = simulate(s.balls);
  s.seq++; s.shot = { seq: s.seq, by: side, frames: sim.frames, pots: sim.pots, sample: SAMPLE, steps: sim.steps };
  s.extraMs = Math.ceil(sim.frames.length * SAMPLE * 1000 / 60) + 800;
  rules(s, side, sim, wasBreak);
  return { ok: true };
}
function rules(s, owner, sim, wasBreak) {
  const opp = other(owner), balls = s.balls, cue = balls[0];
  const pottedBalls = sim.pots.map(p => balls.find(b => b.n === p[0]));
  const potted = pottedBalls.filter(b => b.n !== 0), scratch = pottedBalls.some(b => b.n === 0), eightIn = pottedBalls.some(b => b.n === 8);
  const ev = { by: owner, foul: false, reason: null, potted: potted.map(b => b.n), scratch, rerack: false, group: null };
  s.event = ev;
  if (wasBreak && eightIn) {                                                    // 8 na quebra: monta de novo, mesmo jogador quebra
    s.balls = rack(); s.breakShot = true; s.turn = owner; s.hand = false; ev.rerack = true; return;
  }
  const mine = s.groups[owner];
  const leftBefore = mine ? balls.filter(b => b.type === mine && !b.dead).length + potted.filter(b => b.type === mine).length : null;
  let foul = false, reason = '';
  const first = sim.first;
  if (scratch) { foul = true; reason = 'scratch'; }
  else if (!first) { foul = true; reason = 'no_contact'; }
  else if (!mine) { if (first.n === 8) { foul = true; reason = 'hit_8_first'; } }
  else if (leftBefore > 0) { if (first.type !== mine) { foul = true; reason = first.n === 8 ? 'hit_8_first' : 'hit_opp_first'; } }
  else if (first.n !== 8) { foul = true; reason = 'must_hit_8'; }
  if (!foul && !pottedBalls.length && !sim.rail) { foul = true; reason = 'no_rail'; }
  if (eightIn) {
    const legal = !foul && mine && leftBefore === 0;
    s.phase = 'over'; s.winner = legal ? owner : opp; s.reason = legal ? 'normal' : 'eight_foul';
    ev.foul = !legal; ev.reason = legal ? null : (scratch ? 'scratch' : 'eight_early'); return;
  }
  if (!s.groups[owner] && !foul && !wasBreak) {
    const f1 = potted.find(b => b.type === 'solid' || b.type === 'stripe');
    if (f1) { s.groups[owner] = f1.type; s.groups[opp] = f1.type === 'solid' ? 'stripe' : 'solid'; ev.group = f1.type; }
  }
  let keep = false;
  if (!foul) keep = s.groups[owner] ? potted.some(b => b.type === s.groups[owner]) : potted.length > 0;
  if (scratch) { const sp = freeSpot(balls); cue.dead = false; cue.x = sp[0]; cue.y = sp[1]; cue.vx = cue.vy = 0; }
  s.turn = keep ? owner : opp;
  if (foul) { s.hand = true; ev.foul = true; ev.reason = reason; }
}
const waiting = s => (s.phase === 'play' ? s.turn : null);
function view(s, side) {
  const o = other(side), mine = s.turn === side && s.phase === 'play';
  return {
    phase: s.phase, turn: s.turn === side ? 'me' : 'opp', hand: mine && s.hand, handOpp: !mine && s.hand, breakShot: s.breakShot,
    balls: s.balls.map(b => ({ n: b.n, x: Math.round(b.x * 10) / 10, y: Math.round(b.y * 10) / 10, dead: b.dead, type: b.type })),
    groups: { me: s.groups[side], opp: s.groups[o] }, seq: s.seq, shot: s.shot ? { ...s.shot, by: s.shot.by === side ? 'me' : 'opp' } : null,
    event: s.event ? { ...s.event, by: s.event.by === side ? 'me' : 'opp' } : null,
    winner: s.winner ? (s.winner === side ? 'me' : 'opp') : null, reason: s.reason
  };
}
module.exports = { MODES, create, act, view, waiting, nextHand() {}, simulate, rack };
