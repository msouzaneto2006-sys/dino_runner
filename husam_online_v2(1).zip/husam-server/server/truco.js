'use strict';
// Motor do Truco 1x1 (Mineiro e Paulista). O servidor é a única fonte da verdade:
// o cliente só pede ações e recebe a "visão" do que o jogador pode ver.
const crypto = require('crypto');

const SUITS = ['♠', '♥', '♦', '♣'];
const RANKS = ['A', '2', '3', '4', '5', '6', '7', 'Q', 'J', 'K'];
const ORDER = ['4', '5', '6', '7', 'Q', 'J', 'K', 'A', '2', '3'];
const MODES = ['mineiro', 'paulista'];
const other = s => (s === 'a' ? 'b' : 'a');
const rint = n => crypto.randomInt(n);

function shuffledDeck() {
  const d = [];
  for (const s of SUITS) for (const r of RANKS) d.push({ r, s });
  for (let i = d.length - 1; i > 0; i--) { const j = rint(i + 1); [d[i], d[j]] = [d[j], d[i]]; }
  return d;
}
function manilhaRank(vira) { return vira ? ORDER[(ORDER.indexOf(vira.r) + 1) % ORDER.length] : null; }
function strength(mode, vira, c) {
  if (mode === 'mineiro') {
    if (c.r === '4' && c.s === '♣') return 104;
    if (c.r === '7' && c.s === '♥') return 103;
    if (c.r === 'A' && c.s === '♠') return 102;
    if (c.r === '7' && c.s === '♦') return 101;
    return ORDER.indexOf(c.r);
  }
  if (c.r === manilhaRank(vira)) return 100 + ({ '♦': 1, '♠': 2, '♥': 3, '♣': 4 })[c.s];
  return ORDER.indexOf(c.r);
}
const LADDER = { mineiro: [2, 4, 6, 10, 12], paulista: [1, 3, 6, 9, 12] };
function raiseAfter(mode, v) { const l = LADDER[mode], i = l.indexOf(v); return i >= 0 && i < l.length - 1 ? l[i + 1] : null; }

// resultado da mão a partir das vazas ('a' | 'b' | 't')
function decideHand(tr, starter) {
  const a = tr.filter(x => x === 'a').length, b = tr.filter(x => x === 'b').length;
  if (a >= 2) return 'a';
  if (b >= 2) return 'b';
  if (tr.length === 2) {
    if (tr[0] === 't' && tr[1] !== 't') return tr[1];
    if (tr[0] !== 't' && tr[1] === 't') return tr[0];
    return null;
  }
  if (tr.length === 3) {
    if (tr[2] !== 't') return tr[2];
    return tr.find(x => x !== 't') || starter;
  }
  return null;
}

function create(mode) {
  if (!MODES.includes(mode)) throw new Error('modo inválido');
  const s = { mode, score: { a: 0, b: 0 }, starter: null, phase: 'play', hand: null, winner: null, handNo: 0, lastHand: null };
  newHand(s);
  return s;
}
const mao11 = s => s.score.a === 11 || s.score.b === 11;

function newHand(s) {
  s.handNo++;
  s.starter = s.starter === null ? (rint(2) ? 'a' : 'b') : other(s.starter);
  const d = shuffledDeck();
  const hands = { a: [d.pop(), d.pop(), d.pop()], b: [d.pop(), d.pop(), d.pop()] };
  const vira = s.mode === 'paulista' ? d.pop() : null;
  let points = s.mode === 'mineiro' ? 2 : 1;
  const m11 = mao11(s);
  if (s.mode === 'paulista' && m11) points = 3;
  s.hand = { starter: s.starter, turn: s.starter, leader: s.starter, hands, vira, tricks: [], cur: [], lastTrick: null, points, lastRaiser: null, pending: null, mao11: m11 };
  s.phase = 'play';
}

function waiting(s) {                       // quem precisa agir agora (ou null)
  if (s.phase !== 'play' || !s.hand) return null;
  return s.hand.pending ? other(s.hand.pending.from) : s.hand.turn;
}
function nextRaiseFor(s, side) {
  const h = s.hand;
  if (!h || s.phase !== 'play' || h.pending || h.turn !== side || h.mao11 || h.lastRaiser === side) return null;
  return raiseAfter(s.mode, h.points);
}

function endHand(s, winner, pts, reason) {
  s.score[winner] = Math.min(12, s.score[winner] + pts);
  s.lastHand = { winner, points: pts, reason };
  if (s.score[winner] >= 12) { s.phase = 'over'; s.winner = winner; }
  else s.phase = 'handEnd';
}

function act(s, side, msg) {
  const h = s.hand;
  if (s.phase !== 'play') return { ok: false, error: 'Aguarde a próxima mão.' };
  const a = msg && msg.a;
  if (a === 'play') {
    if (h.pending) return { ok: false, error: 'Responda ao pedido primeiro.' };
    if (h.turn !== side) return { ok: false, error: 'Não é a sua vez.' };
    const i = msg.i;
    if (!Number.isInteger(i) || i < 0 || i >= h.hands[side].length) return { ok: false, error: 'Carta inválida.' };
    const card = h.hands[side].splice(i, 1)[0];
    h.cur.push({ who: side, card });
    if (h.cur.length === 1) { h.turn = other(side); return { ok: true }; }
    // segunda carta da vaza
    const ca = h.cur.find(x => x.who === 'a').card, cb = h.cur.find(x => x.who === 'b').card;
    const sa = strength(s.mode, h.vira, ca), sb = strength(s.mode, h.vira, cb);
    const w = sa > sb ? 'a' : sb > sa ? 'b' : 't';
    h.tricks.push(w);
    h.lastTrick = { a: ca, b: cb, winner: w };
    h.cur = [];
    const res = decideHand(h.tricks, h.starter);
    if (res) { endHand(s, res, h.points, 'normal'); return { ok: true }; }
    h.leader = w === 't' ? h.leader : w;
    h.turn = h.leader;
    return { ok: true };
  }
  if (a === 'raise') {
    if (h.pending) return { ok: false, error: 'Responda ao pedido primeiro.' };
    const v = nextRaiseFor(s, side);
    if (!v) return { ok: false, error: 'Você não pode pedir aumento agora.' };
    h.pending = { from: side, value: v };
    return { ok: true };
  }
  if (a === 'accept' || a === 'run' || a === 'reraise') {
    if (!h.pending || h.pending.from === side) return { ok: false, error: 'Não há pedido para responder.' };
    const p = h.pending;
    if (a === 'run') { endHand(s, p.from, h.points, 'run'); return { ok: true }; }   // quem pediu leva o valor anterior
    h.points = p.value; h.lastRaiser = p.from; h.pending = null;
    if (a === 'accept') return { ok: true };
    const v = h.mao11 ? null : raiseAfter(s.mode, h.points);
    if (!v) return { ok: false, error: 'Não dá para aumentar mais.' };
    h.lastRaiser = side; h.pending = { from: side, value: v };
    return { ok: true };
  }
  return { ok: false, error: 'Ação desconhecida.' };
}
// para o controlador: avançar depois da pausa entre mãos
function nextHand(s) { if (s.phase === 'handEnd') newHand(s); }

function view(s, side) {
  const h = s.hand, me = x => (x === side ? 'me' : 'opp');
  const v = {
    mode: s.mode, phase: s.phase, handNo: s.handNo,
    score: { me: s.score[side], opp: s.score[other(side)] },
    winner: s.winner ? me(s.winner) : null,
    lastHand: s.lastHand ? { winner: me(s.lastHand.winner), points: s.lastHand.points, reason: s.lastHand.reason } : null,
    hand: null
  };
  if (h) {
    const nr = nextRaiseFor(s, side);
    const resp = h.pending && h.pending.from !== side;
    v.hand = {
      myCards: h.hands[side].map(c => ({ r: c.r, s: c.s })),
      oppCount: h.hands[other(side)].length,
      vira: h.vira, manilha: manilhaRank(h.vira),
      tricks: h.tricks.map(t => (t === 't' ? 'tie' : me(t))),
      cur: h.cur.map(x => ({ who: me(x.who), card: x.card })),
      lastTrick: h.lastTrick ? { me: h.lastTrick[side], opp: h.lastTrick[other(side)], winner: h.lastTrick.winner === 't' ? 'tie' : me(h.lastTrick.winner) } : null,
      turn: me(h.turn), starter: me(h.starter),
      points: h.points, mao11: h.mao11,
      pending: h.pending ? { from: me(h.pending.from), value: h.pending.value } : null,
      canRaise: nr || null,
      canReraise: resp && !h.mao11 ? raiseAfter(s.mode, h.pending.value) : null
    };
  }
  return v;
}

module.exports = { MODES, create, act, nextHand, view, waiting, strength, decideHand, raiseAfter, manilhaRank, LADDER };
